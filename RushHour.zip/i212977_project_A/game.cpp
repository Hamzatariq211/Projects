//============================================================================
// Name        : .cpp
// Author      : FAST CS Department
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Rush Hour...
//============================================================================

#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include<fstream>
#include<ctime>
#include<string>
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;

// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}

int xI = 2, yI = 810;
int xA=663, yA=300;
int xS=32, yS=100;
int xD=392,yD=700;
int xE=482, yE=300;
int t=0;
int counter=0;

int a;
void drawCar() {

if(a==1)
{
	DrawSquare(xI, yI, 25, colors[ORANGE]); //Taxi controlled by the user
	DrawCircle(xI+6,yI-5,5,colors[ORANGE]);
	DrawCircle(xI+18,yI-5,5,colors[ORANGE]);
	glutPostRedisplay();
	}
	
else if (a==2)
{
DrawSquare(xI, yI, 25, colors[RED]); //Taxi controlled by the user
	DrawCircle(xI+6,yI-5,5,colors[RED]);
	DrawCircle(xI+18,yI-5,5,colors[RED]);
	glutPostRedisplay();
	}
	}
void drawCar2(){
	DrawSquare(xA,yA , 25, colors[BLUE]);
	DrawCircle(xA+6,yA-5,5,colors[BLUE]);
	DrawCircle(xA+18,yA-5,5,colors[BLUE]);
	glutPostRedisplay();
	}
void drawCar3(){
	DrawSquare(xS,yS , 25, colors[GREEN]);
	DrawCircle(xS+6,yS-5,5,colors[GREEN]);
	DrawCircle(xS+18,yS-5,5,colors[GREEN]);
	glutPostRedisplay();
	}
void drawCar4(){
	DrawSquare(xD,yD , 25, colors[GREEN]);
	DrawCircle(xD+6,yD-5,5,colors[GREEN]);
	DrawCircle(xD+18,yD-5,5,colors[GREEN]);
	glutPostRedisplay();
	}
void drawCar5(){
	DrawSquare(xE,yE , 25, colors[SKY_BLUE]);
	DrawCircle(xE+6,yE-5,5,colors[SKY_BLUE]);
	DrawCircle(xE+18,yE-5,5,colors[SKY_BLUE]);
	
	
	glutPostRedisplay();
	}

int xa=825, ya=790;
int xc=825, yc=360;
int xe=285, ye=500;
int xg=555, yg=210;

int xz=400, yz=400;
int xl=400, yl=100;
int xr=950, yr=150;
int xv=160, yv=800;

int score=0;
void passengers()     //to draw passengers 
{
       //first passenger
       DrawCircle (xa, ya, 8, colors[BLACK]);    
       DrawLine(xa, ya, xa, ya-30, 7, colors[BLACK]);
       // second passenger
       DrawCircle (xc, yc, 8, colors[BLACK]);
       DrawLine(xc, yc, xc, yc-30, 7, colors[BLACK]);
       //third passenger
       DrawCircle (xe, ye, 8, colors[BLACK]);
       DrawLine(xe, ye, xe, ye-30, 7, colors[BLACK]);
       //fourth passenger
       DrawCircle (xg, yg, 8, colors[BLACK]);
       DrawLine(xg, yg, xg, yg-30, 7, colors[BLACK]);

       if (xa==4000)
       DrawCircle(xz,yz,8,colors[GREEN]);
       
       
       if (xc==5000)
       DrawCircle(xl,yl,8,colors[GREEN]);
       
       
       if (xe==6000)
       DrawCircle(xr,yr,8,colors[GREEN]);
       
       
       if (xg==7000)
       DrawCircle(xv,yv,8,colors[GREEN]);
       
       glutPostRedisplay();
       }
	


bool flag = true;
void moveCar() {
        
	// moving blue car vertically
	if (yA > 10 && flag) {
		yA -= 10;
		if(yA < 150 )			
			flag = false;
	}
	else if (yA < 840 && !flag) {
		yA += 10;
		if (yA > 800)
			flag = true;		
	}
	}
	
void moveCar2(){
	// moving green car in second column vertically
	if (yS > 10 && flag) {
		yS -= 10;
		if(yS < 50 )			
		flag = false;
	}
	else if (yS < 840 && !flag) {
		yS += 10;
		if (yS > 700)
			flag = true;
	}
	}		
	
	

void moveCar3(){	
	// moving second green car horizontally
	if (xD > 10 && flag) {
		xD -= 10;
		if(xD < 200)
			
			flag = false;

	}
	else if (xD < 840 && !flag) {
		xD += 10;
		if (xD > 700)
			flag = true;
	}
			}
			
void moveCar4(){		
		// moving sky blue car vertically	
		if (yE > 10 && flag) {
		yE -= 10;
		if(yE < 50)
			
			flag = false;

	}
	else if (yE < 840 && !flag) {
		yE += 10;
		if (yE > 700)
			flag = true;
	}
			}
			
			
	
void restriction(){       // this functions is used so that the car controlled manually cannot pass the buildings 
// first block 
if (yI<=740 && yI>=640 && xI==32){
xI-=10;
score-=2;}
else if (yI<=740 && yI>=640 && xI==152){
xI+=10;
score-=2;}
else if (xI<=150 && xI>=40 && yI==740){
yI+=10;
score-=2;}
else if (xI<=150 && xI>=40 && yI==630){
yI-=10;
score-=2;}
// second block
else if (yI<=530 && yI>=460 && xI==32){
xI-=10;
score-=2;}
else if (yI<=460 && yI>=380 && xI==62){
xI-=10;
score-=2;}
else if (yI<=530 && yI>=380 && xI==122){
xI+=10;
score-=2;}
else if (xI<=120 && xI>=40 && yI==530){
yI+=10;
score-=2;}
else if (xI<=90 && xI>=40 && yI==460){
yI-=10;
score-=2;}
else if (xI<=120 && xI>=60 && yI==380){
yI-=10;
score-=2;}
// third block
else if (yI<=250 && yI>=110 && xI==32){
xI-=10;
score-=2;}
else if (yI<=250 && yI>=110 && xI==122){
xI+=10;
score-=2;}
else if (xI<=120 && xI>=40 && yI==250){
yI+=10;
score-=2;}
else if (xI<=120 && xI>=40 && yI==110){
yI-=10;
score-=2;}
// fourth block
else if (yI<=120 && yI>=0 && xI==282){
xI-=10;
score-=2;}
else if (yI<=120 && yI>=0 && xI==332){
xI+=10;
score-=2;}
else if (xI<=330 && xI>=290 && yI==120){
yI+=10;
score-=2;}
// fifth block
else if (yI<=480 && yI>=330 && xI==322){
xI+=10;
score-=2;}
else if (yI<=470 && yI>=360 && xI==282){
xI-=10;
score-=2;}
else if (yI<=380 && yI>=330 && xI==192){
xI-=10;
score-=2;}
else if (xI<=330 && xI>=200 && yI==330){
yI-=10;
score-=2;}
else if (xI<=300 && xI>=200 && yI==370){
yI+=10;
score-=2;}
else if (xI<=330 && xI>=280 && yI==470){
yI+=10;
score-=2;}
//sixth block
else if (yI<=680 && yI>=490 && xI==262){
xI+=10;
score-=2;}
else if (yI<=530 && yI>=490 && xI==162){
xI-=10;
score-=2;}
else if (yI<=590 && yI>=520 && xI==192){
xI-=10;
score-=2;}
else if (yI<=680 && yI>=590 && xI==222){
xI-=10;
score-=2;}
else if (xI<=270 && xI>=170 && yI==490){
yI-=10;
score-=2;}
else if (xI<=270 && xI>=230 && yI==680){
yI+=10;
score-=2;}
else if (xI<=240 && xI>=170 && yI==530){
yI+=10;
score-=2;}
else if (xI<=240 && xI>=200 && yI==590){
yI+=10;
score-=2;}
// seventh block
else if (yI<=630 && yI>=520 && xI==322){
xI+=10;
score-=2;}
else if (yI<=630 && yI>=520 && xI==282){
xI-=10;
score-=2;}
else if (xI<=320 && xI>=280 && yI==630){
yI+=10;
score-=2;}
else if (xI<=320 && xI>=280 && yI==520){
yI-=10;
score-=2;}
//eighth block
else if (yI<=350 && yI>=160 && xI==382){
xI+=10;
score-=2;}
else if (yI<=350 && yI>=160 && xI==342){
xI-=10;
score-=2;}
else if (yI<=250 && yI>=160 && xI==252){
xI-=10;
score-=2;}
else if (yI<=250 && yI>=160 && xI==292){
xI+=10;
score-=2;}
else if (yI<=200 && yI>=160 && xI==192){
xI-=10;
score-=2;}
else if (xI<=390 && xI>=200 && yI==160){
yI-=10;
score-=2;}
else if (xI<=360 && xI>=200 && yI==210){
yI+=10;
score-=2;}
else if (xI<=300 && xI>=260 && yI==250){
yI+=10;
score-=2;}
else if (xI<=390 && xI>=350 && yI==350){
yI+=10;
score-=2;}
// ninth block
else if (yI<=620 && yI>=370 && xI==472){
xI+=10;
score-=2;}
else if (yI<=620 && yI>=370 && xI==432){
xI-=10;
score-=2;}
else if (xI<=480 && xI>=440 && yI==620){
yI+=10;
score-=2;}
else if (xI<=480 && xI>=440 && yI==370){
yI-=10;
score-=2;}
// tenth block
else if (yI<=170 && yI>=0 && xI==562){
xI+=10;
score-=2;}
else if (yI<=170 && yI>=0 && xI==522){
xI-=10;
score-=2;}
else if (xI<=570 && xI>=530 && yI==180){
yI+=10;
score-=2;}
//eleventh block
else if (yI<=670 && yI>=480 && xI==522){
xI-=10;
score-=2;}
else if (yI<=670 && yI>=480 && xI==562){
xI+=10;
score-=2;}
else if (yI<=520 && yI>=480 && xI==652){
xI+=10;
score-=2;}
else if (xI<=660 && xI>=530 && yI==480){
yI-=10;
score-=2;}
else if (xI<=660 && xI>=560 && yI==530){
yI+=10;
score-=2;}
else if (xI<=570 && xI>=530 && yI==680){
yI+=10;
score-=2;}
// twelvth block
else if (yI<=670 && yI>=430 && xI==982){
xI+=10;
score-=2;}
else if (yI<=670 && yI>=430 && xI==942){
xI-=10;
score-=2;}
else if (xI<=990 && xI>=950 && yI==680){
yI+=10;
score-=2;}
else if (xI<=990 && xI>=950 && yI==430){
yI-=10;
score-=2;}
//thirteenth block
else if (yI<=130 && yI>=80 && xI==982){
xI+=10;
score-=2;}
else if (yI<=130 && yI>=80 && xI==882){
xI-=10;
score-=2;}
else if (xI<=990 && xI>=890 && yI==80){
yI-=10;
score-=2;}
else if (xI<=990 && xI>=890 && yI==130){
yI+=10;
score-=2;}
// fourteenth block
else if (yI<=130 && yI>=20 && xI==712){
xI+=10;
score-=2;}
else if (yI<=130 && yI>=20 && xI==642){
xI-=10;
score-=2;}
else if (xI<=720 && xI>=650 && yI==20){
yI-=10;
score-=2;}
else if (xI<=720 && xI>=650 && yI==130){
yI+=10;
score-=2;}
//fifteenth block
else if (yI<=330 && yI>=130 && xI==792){
xI-=10;
score-=2;}
else if (yI<=330 && yI>=130 && xI==832){
xI+=10;
score-=2;}
else if (yI<=380 && yI>=330 && xI==852){
xI-=10;
score-=2;}
else if (yI<=380 && yI>=330 && xI==892){
xI+=10;
score-=2;}
else if (xI<=1020 && xI>=790 && yI==330){
yI+=10;
score-=2;}
else if (xI<=1020 && xI>=800 && yI==280){
yI-=10;
score-=2;}
else if (xI<=840 && xI>=800 && yI==130){
yI-=10;
score-=2;}
// sixteenth block
else if (yI<=760 && yI>=710 && xI==612){
xI-=10;
score-=2;}
else if (yI<=800 && yI>=760 && xI==702){
xI-=10;
score-=2;}
else if (yI<=800 && yI>=760 && xI==742){
xI+=10;
score-=2;}
else if (xI<=1020 && xI>=620 && yI==710){
yI-=10;
score-=2;}
else if (xI<=1020 && xI>=620 && yI==760){
yI+=10;
score-=2;}
else if (xI<=750 && xI>=710 && yI==800){
yI+=10;
score-=2;}
// seventeenth block
else if (yI<=670 && yI>=430 && xI==732){
xI-=10;
score-=2;}
else if (yI<=670 && yI>=430 && xI==772){
xI+=10;
score-=2;}
else if (yI<=580 && yI>=530 && xI==892){
xI+=10;
score-=2;}
else if (xI<=900 && xI>=770 && yI==530){
yI-=10;
score-=2;}
else if (xI<=900 && xI>=770 && yI==580){
yI+=10;
score-=2;}
else if (xI<=780 && xI>=740 && yI==430){
yI-=10;
score-=2;}
else if (xI<=780 && xI>=740 && yI==680){
yI+=10;
score-=2;}
// eigheenth block
else if (yI<=430 && yI>=200 && xI==652){
xI+=10;
score-=2;}
else if (yI<=430 && yI>=200 && xI==612){
xI-=10;
score-=2;}
else if (yI<=340 && yI>=290 && xI==522){
xI-=10;
score-=2;}
else if (yI<=390 && yI>=340 && xI==552){
xI-=10;
score-=2;}
else if (yI<=390 && yI>=340 && xI==592){
xI+=10;
score-=2;}
else if (xI<=630 && xI>=530 && yI==340){
yI+=10;
score-=2;}
else if (xI<=630 && xI>=530 && yI==290){
yI-=10;
score-=2;}
else if (xI<=600 && xI>=560 && yI==390){
yI+=10;
score-=2;}
else if (xI<=660 && xI>=620 && yI==200){
yI-=10;
score-=2;}
else if (xI<=660 && xI>=620 && yI==430){
yI+=10;
score-=2;}
glutPostRedisplay();
}




/*
 * Main Canvas drawing function.
 * */
      
void GameDisplay()/**/{

	// set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.
	glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	

	//A big square to make the background white
	DrawSquare( 0 , 0 ,2000,colors[WHITE]);
	//DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)
	DrawLine(  0, 0 ,  0 , 840 , 1 , colors[BLACK] );
	DrawLine( 30 , 0 ,  30 , 840 , 1 , colors[BLACK] );	
	DrawLine( 60 , 0 ,  60 , 840 , 1 , colors[BLACK] );
        DrawLine( 90 , 0 ,  90 , 840 , 1 , colors[BLACK] );
        DrawLine( 120 , 0 ,  120 , 840 , 1 , colors[BLACK] );
	DrawLine( 150 , 0 ,  150 , 840 , 1 , colors[BLACK] );
	DrawLine( 180 , 0 ,  180 , 840 , 1 , colors[BLACK] );
	DrawLine( 210 , 0 ,  210 , 840 , 1 , colors[BLACK] );
	DrawLine( 240 , 0 ,  240 , 840 , 1 , colors[BLACK] );
	DrawLine( 270 , 0 ,  270 , 840 , 1 , colors[BLACK] );
	DrawLine( 300 , 0 ,  300 , 840 , 1 , colors[BLACK] );
	DrawLine( 330 , 0 ,  330 , 840 , 1 , colors[BLACK] );
	DrawLine( 360 , 0 ,  360 , 840 , 1 , colors[BLACK] );
	DrawLine( 390 , 0 ,  390 , 840 , 1 , colors[BLACK] );
	DrawLine( 420 , 0 ,  420 , 840 , 1 , colors[BLACK] );
	DrawLine( 450 , 0 ,  450 , 840 , 1 , colors[BLACK] );
	DrawLine( 480 , 0 ,  480 , 840 , 1 , colors[BLACK] );
	DrawLine( 510 , 0 ,  510 , 840 , 1 , colors[BLACK] );
	DrawLine( 540 , 0 ,  540 , 840 , 1 , colors[BLACK] );
	DrawLine( 570 , 0 ,  570 , 840 , 1 , colors[BLACK] );
	DrawLine( 600 , 0 ,  600 , 840 , 1 , colors[BLACK] );
	DrawLine( 630 , 0 ,  630 , 840 , 1 , colors[BLACK] );
	DrawLine( 660 , 0 ,  660 , 840 , 1 , colors[BLACK] );
	DrawLine( 690 , 0 ,  690 , 840 , 1 , colors[BLACK] );
	DrawLine( 720 , 0 ,  720 , 840 , 1 , colors[BLACK] );
	DrawLine( 750 , 0 ,  750 , 840 , 1 , colors[BLACK] );
	DrawLine( 780 , 0 ,  780 , 840 , 1 , colors[BLACK] );
	DrawLine( 810 , 0 ,  810 , 840 , 1 , colors[BLACK] );
	DrawLine( 840 , 0 ,  840 , 840 , 1 , colors[BLACK] );
	DrawLine( 870 , 0 ,  870 , 840 , 1 , colors[BLACK] );
	DrawLine( 900 , 0 ,  900 , 840 , 1 , colors[BLACK] );
	DrawLine( 930 , 0 ,  930 , 840 , 1 , colors[BLACK] );
	DrawLine( 960 , 0 ,  960 , 840 , 1 , colors[BLACK] );
	DrawLine( 990 , 0 ,  990 , 840 , 1 , colors[BLACK] );
	DrawLine( 1020 , 0 ,  1020 , 840 , 1 , colors[BLACK] );
	
	DrawRectangle(60, 130, 62, 130, colors[BLACK]);
	DrawSquare (60, 650, 91, colors[BLACK]);
	DrawSquare (60, 480, 61, colors[BLACK]);
	DrawSquare (90, 450, 31, colors[BLACK]);
	DrawSquare (90, 420, 31, colors[BLACK]);
	DrawSquare (90, 400, 31, colors[BLACK]);
	DrawSquare (180, 510, 31, colors[BLACK]);
	DrawSquare (210, 510, 31, colors[BLACK]);
	DrawSquare (240, 510, 31, colors[BLACK]);
	DrawSquare (240, 650, 31, colors[BLACK]);
	DrawSquare (240, 620, 31, colors[BLACK]);
	DrawSquare (240, 590, 31, colors[BLACK]);
	DrawSquare (240, 560, 31, colors[BLACK]);
	DrawSquare (240, 530, 31, colors[BLACK]);
	DrawSquare (210, 180, 31, colors[BLACK]);
	DrawSquare (240, 180, 31, colors[BLACK]);
	DrawSquare (270, 180, 31, colors[BLACK]);
	DrawSquare (300, 180, 31, colors[BLACK]);
	DrawSquare (330, 180, 31, colors[BLACK]);
	DrawSquare (360, 180, 31, colors[BLACK]);
	DrawSquare (360, 320, 31, colors[BLACK]);
	DrawSquare (360, 290, 31, colors[BLACK]);
	DrawSquare (360, 260, 31, colors[BLACK]);
	DrawSquare (360, 230, 31, colors[BLACK]);
	DrawSquare (360, 200, 31, colors[BLACK]);
	DrawSquare (360, 180, 31, colors[BLACK]);
	DrawSquare (300, 100, 31, colors[BLACK]);
	DrawSquare (300, 70, 31, colors[BLACK]);
	DrawSquare (300, 40, 31, colors[BLACK]);
	DrawSquare (300, 10, 31, colors[BLACK]);
	DrawSquare (300, 0, 31, colors[BLACK]);
	DrawSquare (210, 350, 31, colors[BLACK]);
	DrawSquare (240, 350, 31, colors[BLACK]);
	DrawSquare (270, 350, 31, colors[BLACK]);
	DrawSquare (300, 350, 31, colors[BLACK]);
	DrawSquare (300, 450, 31, colors[BLACK]);
	DrawSquare (300, 420, 31, colors[BLACK]);
	DrawSquare (300, 390, 31, colors[BLACK]);
	DrawSquare (300, 360, 31, colors[BLACK]);
	DrawSquare (300, 350, 31, colors[BLACK]);
	DrawSquare (300, 600, 31, colors[BLACK]);
	DrawSquare (300, 570, 31, colors[BLACK]);
	DrawSquare (300, 540, 31, colors[BLACK]);
	DrawSquare (630, 730, 31, colors[BLACK]);
	DrawSquare (660, 730, 31, colors[BLACK]);
	DrawSquare (690, 730, 31, colors[BLACK]);
	DrawSquare (720, 730, 31, colors[BLACK]);
	DrawSquare (750, 730, 31, colors[BLACK]);
	DrawSquare (780, 730, 31, colors[BLACK]);
	DrawSquare (810, 730, 31, colors[BLACK]);
       DrawSquare (840, 730, 31, colors[BLACK]);
       DrawSquare (870, 730, 31, colors[BLACK]);
       DrawSquare (900, 730, 31, colors[BLACK]);
       DrawSquare (930, 730, 31, colors[BLACK]);
       DrawSquare (960, 730, 31, colors[BLACK]);
       DrawSquare (990, 730, 31, colors[BLACK]);
       DrawSquare (1020, 730, 31, colors[BLACK]);
       DrawSquare (750, 650, 31, colors[BLACK]);
       DrawSquare (750, 630, 31, colors[BLACK]);
       DrawSquare (750, 600, 31, colors[BLACK]);
       DrawSquare (750, 570, 31, colors[BLACK]);
       DrawSquare (750, 540, 31, colors[BLACK]);
       DrawSquare (750, 510, 31, colors[BLACK]);
       DrawSquare (750, 480, 31, colors[BLACK]);
       DrawSquare (750, 450, 31, colors[BLACK]);
       DrawSquare (780, 550, 31, colors[BLACK]);
       DrawSquare (810, 550, 31, colors[BLACK]);
       DrawSquare (840, 550, 31, colors[BLACK]);
       DrawSquare (870, 550, 31, colors[BLACK]);
       DrawSquare (960, 650, 31, colors[BLACK]);
       DrawSquare (960, 620, 31, colors[BLACK]);
       DrawSquare (960, 590, 31, colors[BLACK]);
       DrawSquare (960, 560, 31, colors[BLACK]);
       DrawSquare (960, 530, 31, colors[BLACK]);
       DrawSquare (960, 500, 31, colors[BLACK]);
       DrawSquare (960, 470, 31, colors[BLACK]);
       DrawSquare (960, 450, 31, colors[BLACK]);
       DrawSquare (810, 300, 31, colors[BLACK]);
       DrawSquare (810, 270, 31, colors[BLACK]);
       DrawSquare (810, 240, 31, colors[BLACK]);
       DrawSquare (810, 210, 31, colors[BLACK]);
       DrawSquare (810, 180, 31, colors[BLACK]);
       DrawSquare (810, 150, 31, colors[BLACK]);
       DrawSquare (840, 300, 31, colors[BLACK]);
       DrawSquare (870, 300, 31, colors[BLACK]);
       DrawSquare (900, 300, 31, colors[BLACK]);
       DrawSquare (930, 300, 31, colors[BLACK]);
       DrawSquare (960, 300, 31, colors[BLACK]);
       DrawSquare (990, 300, 31, colors[BLACK]);
       DrawSquare (900, 100, 31, colors[BLACK]);
       DrawSquare (930, 100, 31, colors[BLACK]);
       DrawSquare (960, 100, 31, colors[BLACK]);
       DrawSquare (450, 600, 31, colors[BLACK]);
       DrawSquare (450, 570, 31, colors[BLACK]);
       DrawSquare (450, 540, 31, colors[BLACK]);
       DrawSquare (450, 510, 31, colors[BLACK]);
       DrawSquare (450, 480, 31, colors[BLACK]);
       DrawSquare (450, 450, 31, colors[BLACK]);
       DrawSquare (450, 420, 31, colors[BLACK]);
       DrawSquare (450, 390, 31, colors[BLACK]); 
       DrawSquare (540, 150, 31, colors[BLACK]);
       DrawSquare (540, 120, 31, colors[BLACK]);
       DrawSquare (540, 90, 31, colors[BLACK]);
       DrawSquare (540, 60, 31, colors[BLACK]);
       DrawSquare (540, 30, 31, colors[BLACK]);
       DrawSquare (540, 0, 31, colors[BLACK]);  
       DrawSquare (630, 400, 31, colors[BLACK]); 
       DrawSquare (630, 370, 31, colors[BLACK]); 
       DrawSquare (630, 340, 31, colors[BLACK]);
       DrawSquare (630, 310, 31, colors[BLACK]);
       DrawSquare (630, 280, 31, colors[BLACK]);
       DrawSquare (630, 250, 31, colors[BLACK]);
       DrawSquare (630, 220, 31, colors[BLACK]); 
       DrawSquare (540, 310, 31, colors[BLACK]);
       DrawSquare (570, 310, 31, colors[BLACK]);
       DrawSquare (600, 310, 31, colors[BLACK]);  
       DrawSquare (540, 650, 31, colors[BLACK]);
        DrawSquare (540, 620, 31, colors[BLACK]);
         DrawSquare (540, 590, 31, colors[BLACK]);
          DrawSquare (540, 560, 31, colors[BLACK]);
           DrawSquare (540, 530, 31, colors[BLACK]); 
        DrawSquare (540, 500, 31, colors[BLACK]);
         DrawSquare (570, 500, 31, colors[BLACK]);
         DrawSquare (600, 500, 31, colors[BLACK]);
          DrawSquare (630, 500, 31, colors[BLACK]);
           DrawSquare (660, 100, 31, colors[BLACK]);
            DrawSquare (660, 70, 31, colors[BLACK]);
            DrawSquare (660, 40, 31, colors[BLACK]);
            DrawSquare (690, 100, 31, colors[BLACK]);
            DrawSquare (690, 70, 31, colors[BLACK]);
            DrawSquare (690, 40, 31, colors[BLACK]);
            DrawCircle(285,245,13,colors[GREEN]);
            DrawLine(  285, 240 ,  285 , 210 , 10 , colors[KHAKI] );
            DrawCircle(735,790,13,colors[GREEN]);
            DrawLine(  735, 785 ,  735 , 760 , 10 , colors[KHAKI] );
	    DrawCircle(225,580,13,colors[GREEN]);
	    DrawLine(  225, 575 ,  225 , 540 , 10 , colors[KHAKI] );
	    DrawCircle(585,380,13,colors[GREEN]);
	    DrawLine(  585, 375 ,  585 , 340 , 10 , colors[KHAKI] );
	    DrawCircle(885,370,13,colors[GREEN]);
	    DrawLine( 885, 365 ,  885 , 330 , 10 , colors[KHAKI] );
	    //Display Time
	    DrawString( 900, 810, "TIME=", colors[BLACK]);
	DrawString( 950, 810, to_string(t), colors[BLACK]);
	//Display Score
	DrawString( 900, 780, "Score=", colors[BLACK]);
	DrawString(950, 780,  to_string(score), colors[BLACK]);
	    
	 passengers();
	 drawCar();
	drawCar2();
	drawCar3();
	drawCar4();
	drawCar5();
	restriction();
	
	glutSwapBuffers(); // do not modify this line..

}



/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x, int y) {
	if (key
			== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...
		xI -= 10;
		}
		

	else if (key
			== GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {
		xI += 10;
		
	} else if (key
			== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {
		yI +=10;
		
	}

	else if (key
			== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {
		yI -=10;
		
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}



/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}
	
	
	//if (xI==

	if (key == 'b' || key == 'B') //Key for placing the bomb
			{
		//do something if b is pressed
		cout << "b pressed" << endl;

	}
	
	if (key==32) {
	if ((xI>=xa-42 && xI<=xa+42) && (yI>=ya-30 && yI<=ya+30))
	xa=4000;
	if (key==32 && (xI>=xz-42 && xI<=xz+42) && (yI>=yz-30 && yI<=yz+30)){
	xa=xz;
	ya=yz;
	score=score+10;
	}
	}
	
	if (key==32) {
	if ((xI>=xc-42 && xI<=xc+42) && (yI>=yc-30 && yI<=yc+30))
	xc=5000;
	if (key==32 && (xI>=xl-42 && xI<=xl+42) && (yI>=yl-30 && yI<=yl+30)){
	xc=xl;
	yc=yl;
	score+=10;}
	}
	
	if (key==32) {
	if ((xI>=xe-42 && xI<=xe+42) && (yI>=ye-30 && yI<=ye+30))
	xe=6000;
	if (key==32 && (xI>=xr-42 && xI<=xr+42) && (yI>=yr-30 && yI<=yr+30)){
	xe=xr;
	ye=yr;
	score+=10;}
	}
	
	if (key==32) {
	if ((xI>=xg-42 && xI<=xg+42) && (yI>=yg-30 && yI<=yg+30))
	xg=7000;
	if (key==32 && (xI>=xv-42 && xI<=xv+42) && (yI>=yv-30 && yI<=yv+30)){
	xg=xv;
	yg=yv;
	score+=10;}
	}
	glutPostRedisplay();
}
  

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {

	// implement your functionality here
	moveCar();
	moveCar2();
	moveCar3();
	moveCar4();
	counter++;
	if(counter%10==0)
	{
	t++;
	}
	
	

	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(100, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {
	//cout << x << " " << y << endl;
	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{
			cout<<"Right Button Pressed"<<endl;

	}
	glutPostRedisplay();
}

string name;
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {

	int width = 1020, height = 840; // i have set my window size to be 800 x 600
	
        cout<<"Press 1 to choose yellow taxi and press 2 to choose red taxi"<<endl;
        cin>>a;
        cout<<"Please enter your name"<<endl;
        cin>>name;
	InitRandomizer(); // seed the random number generator...
	
	
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("Rush Hour by Azmeer Sohail"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...
	
	

 
	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.
   
	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* RushHour_CPP_ */
