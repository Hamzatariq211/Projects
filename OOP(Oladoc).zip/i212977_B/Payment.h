
#pragma once
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
class Payment {
protected:
	int total_amount;
	int balance;
public:
	Payment() {
		total_amount = 0;
		balance = 0;
	}
	Payment(int amount, int b) {
		total_amount = amount;
		balance = b;
	}
	virtual void Pay() {

	}
	virtual void Display() {
		cout << "Total amount= " << total_amount << endl;
		cout << "Your current balance is: " << balance << endl;
	}
	virtual void Details() {

	}
};

class Banktransfer : public Payment {
protected:
	string accountnumber;
public:
	Banktransfer() {
		total_amount = 0;
		balance = 0;
		accountnumber = '\0';
	}
	Banktransfer(int amou, int bal, string accno) :Payment(amou, bal) {
		accountnumber = accno;
	}

	void Details() {
		cout << "Please enter your account number." << endl;
		cin >> accountnumber;
		cout << endl;
	}
	void Pay() {

		cout << "Your Payment is being processed" << endl;
	}
	void Display() {
		cout << "Your account number is: " << accountnumber << endl;
	}
};

class Paypak : public Banktransfer {
private:
	string account_holder_name, securitycode;
public:
	Paypak() {
		total_amount = 0;
		balance = 0;
		accountnumber = '\0';
		account_holder_name = '\0';
		securitycode = '\0';
	}
	Paypak(int total_amou, int Balance, string acc_no, string name, string code) {
		total_amount = total_amou;
		balance = Balance;
		accountnumber = acc_no;
		account_holder_name = name;
		securitycode = code;
	}
	void Pay() {
		if (balance - total_amount > 0) {
			cout << "Transaction successful" << endl;
		}
		else {
			cout << "Payment not done" << endl;
		}
	}

	void Details() {
		cout << "Please enter your name " << endl;
		cin >> account_holder_name;
		cout << "Please enter the security code " << endl;
		cin >> securitycode;
		cout << endl;
	}

	void Display() {
		cout << "The name of the account holder is: " << account_holder_name << endl;
		cout << "Total amount to be paid= " << total_amount << endl;
		cout << "Balance in the account= " << balance << endl;
		//cout << "Your account number= " << accountnumber << endl;
		cout << "Your security code is: " << securitycode << endl;

	}

};

class Unionpay : public Banktransfer {
	string CNIC, name;
public:
	Unionpay() {
		total_amount = 0;
		balance = 0;
		accountnumber = '\0';
		name = '\0';
		CNIC = '\0';
	}
	Unionpay(int totalamount, int balance, string Accnum, string cnic, string name) {
		total_amount = totalamount;
		this->balance = balance;
		accountnumber = Accnum;
		CNIC = cnic;
		this->name = name;
	}
	void Pay() {
		if (balance - total_amount > 0) {
			cout << "Transaction successful" << endl;
		}
		else {
			cout << "Payment not done" << endl;
		}
	}

	void Details() {
		cout << "Please enter your name " << endl;
		cin >> name;
		cout << "Please enter your CNIC  " << endl;
		cin >> CNIC;
		cout << endl;
	}

	void Display() {
		cout << "Name: " << name << endl;
		cout << "Total amount to be paid= " << total_amount << endl;
		cout << "Balance in the account= " << balance << endl;
		cout << "Your account number= " << accountnumber << endl;
		cout << "Your CNIC is: " << CNIC << endl;

	}
};


class E_transaction : public Payment {
protected:
	string mobilenumber, name;
public:

	E_transaction() {
		total_amount = 0;
		balance = 0;
		mobilenumber = '\0';
		name = '\0';
	}
	E_transaction(int amount, int bal, string mobileno, string n) : Payment(amount, bal) {
		mobilenumber = mobileno;
		name = n;
	}
	void Details() {
		cout << "Please enter your name " << endl;
		cin >> name;
		cout << "Please enter your mobile number " << endl;
		cin >> mobilenumber;
		cout << endl;
	}
	void Pay() {

		cout << "Your Payment is being processed" << endl;
	}
	void Display() {
		cout << "Your name is: " << name << endl;
		cout << "Your mobile number is: " << mobilenumber << endl;
	}
};

class Jazzcash : public E_transaction {
public:
	Jazzcash() {
		total_amount = 0;
		balance = 0;
		mobilenumber = '\0';
		name = '\0';
	}
	Jazzcash(int Amount, int baL, string no, string nam) {
		total_amount = Amount;
		balance = baL;
		mobilenumber = no;
		name = nam;
	}
	void Pay() {
		if (balance - total_amount > 0) {
			cout << "Transaction successful" << endl;
		}
		else {
			cout << "Payment not done" << endl;
		}
	}

	void Details() {

	}

	void Display() {


	}
};

class Easypaisa : public E_transaction {
public:
	Easypaisa() {
		total_amount = 0;
		balance = 0;
		mobilenumber = '\0';
		name = '\0';
	}
	Easypaisa(int Amount, int baL, string no, string nam) {
		total_amount = Amount;
		balance = baL;
		mobilenumber = no;
		name = nam;
	}
	void Pay() {
		if (balance - total_amount > 0) {
			cout << "Transaction successful" << endl;
		}
		else {
			cout << "Payment not done" << endl;
		}
	}

	void Details() {

	}

	void Display() {


	}

};