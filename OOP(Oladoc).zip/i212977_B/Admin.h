
#pragma once
#include<ctime>
#include<iostream>
#include<string>
#include<fstream>
#include"User.h"
#include"Patient.h"
#include"Doctor.h"
#include"Appointment.h"
using namespace std;
class Admin : public User {
private:
	Patient* list_of_patients;
	Appointment* appointments;
	Doctor* doctor;
public:
	Admin(string user_name, string pass) {
		strcpy_s(username, user_name.c_str());
		strcpy_s(set_password, pass.c_str());
	}

	Admin(Patient* list, Appointment* app) {
		list_of_patients = list;
		appointments = app;
	}

	Admin(Doctor* d) {
		doctor = d;
	}

	void Display() {
		cout << "Username: " << username << endl;
		cout << "Password: " << set_password << endl;
		cout << "Patients Details" << endl;
		
	}

	void Login() {
		string U, P;
		cout << "Enter Username:  " << endl;
		cin >> U;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> P;
		cout << endl;
		if (U == username && P == set_password) cout << "Welcome to the admin of " << U << "!" << endl;
		else {
			cout << "Wrong credentials, Enter again!" << endl;
			Login();
		}
	}
	void write(string file_name, Admin obj)
	{
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	void read(string file_name) {
		Admin obj(" ", "");
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			obj.Display();
		}

		fin.close();
	}

	void Add() {
		Doctor* doc = new Doctor();
		cout << "New doctor successfully added" << endl;
	}

	void Edit() {
		
	}

	void Delete() {
		delete [] doctor;
		doctor = NULL;
		cout << "Doctor successfully deleted" << endl;
	}

	void view() {
		Doctor d;
		d.read("doctor.dat");
	}

	void view_Patient() {
		Patient p;
		p.read("patient.dat");
	}

	void Logout() {
		cout << "You have been logged out" << endl;
	}

	void UpdateAppointment() {

	}

	void CancelAppointment() {

	}

	void appointment_details() {

	}
};