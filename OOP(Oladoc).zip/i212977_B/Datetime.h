#pragma once
#include<iostream>
#include<string>
#include<fstream>
using namespace std;

class Datetime {
private:
	int hour, min;
	int day, month, year;
public:
	Datetime() {
		hour = 0;
		min = 0;
		day = 0;
		month = 0;
		year = 0;

	}

	Datetime(int h, int m, int d, int mon, int y) {
		hour = h;
		min = m;
		day = d;
		month = mon;
		year = y;
	}

	int gethour() {
		return hour;
	}
	int getmin() {
		return min;
	}
	int getDay() {
		return day;
	}
	int getmonth() {
		return month;
	}
	int getYear() {
		return year;
	}

	void Display() {
		cout << "Your appointment has been booked for " << day << "/" << month << "/" << year << endl;
		cout << "The time of the appointment is " << hour << ":" << min << endl;
	}
};
