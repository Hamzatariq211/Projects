#include<iostream>
#include<string>
#include<fstream>
#include<stdlib.h>
using namespace std;
#include"Admin.h"
#include"Appointment.h"
#include"DateTime.h"
#include"Doctor.h"
#include"Feedback.h"
#include"Oladoc.h"
#include"Patient.h"
#include"Payment.h"
#include"User.h"

int main() {

	Oladoc o;
	o.Display();

	
	}