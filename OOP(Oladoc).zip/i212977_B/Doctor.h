#pragma once
#include<iostream>
#include<string>
#include<fstream>
#include<cstring>
#include"User.h"
#include"Appointment.h"
using namespace std;
class Doctor : public User {
protected:
	//Appointment* Appointments[100];
	char speciality[100];
	char  location[100],hospital[100];
	int availabilty_from, availability_to;
	int rates, years_of_experience;
	char CNIC[15], set_Password[20];
	bool CNIC_check = false, password_check = false;
public:
	Doctor() {
		years_of_experience = 0;
		rates = 0;
		availabilty_from = 0;
		availability_to = 0;
		CNIC_check = false;
		password_check = false;
	}
	Doctor(string user_n, string Pass_word, string mail, int experience, string cnic, string set_pass, string repass) : User(user_n, Pass_word) {

		strcpy_s(CNIC, cnic.c_str());
		strcpy_s(set_Password, set_pass.c_str());
		years_of_experience = experience;

	}

	Doctor(string user, string special, string hosp) {
		strcpy_s(username, user.c_str());
		strcpy_s(speciality, special.c_str());
		strcpy_s(hospital, hosp.c_str());

	}

	Doctor(string name, string set_Pass, string CNIc, string e_mail) {
		strcpy_s(username, name.c_str());
		strcpy_s(CNIC, CNIc.c_str());
		strcpy_s(set_Password, set_Pass.c_str());
	}


	/*void set_CNIC(string cnic) {
		CNIC = cnic;
	}*/


	int get_availfrom() {
		return availabilty_from;
	}

	int get_availto() {
		return availability_to;
	}

	string get_CNIC() {
		return CNIC;
	}

	string getHospital() {
		return hospital;
	}

	string getspeciality() {
		return speciality;
	}

	string getName() {
		return username;
	}

	string getLocation() {
		return location;
	}

	void Details() {
		cout << "Enter your speciality" << endl;
		cin >> speciality;
		cout << "Enter your name" << endl;
		cin >> username;
		cout << "Please enter your availability hours, you are available from: " << endl;
		cin >> availabilty_from;
		cout << "Available hours, you are available to:" << endl;
		cin >> availability_to;
		cout << "Please enter your location." << endl;
		cin >> location;
		cout << "Please enter your years of experience." << endl;
		cin >> years_of_experience;
		cout << "Please enter your checkup rate." << endl;
		cin >> rates;
	}

	void Register() {
		cout << "Enter your speciality" << endl;
		cin >> speciality;
		cout << endl;
		cout << "Enter your name" << endl;
		cin >> username;
		cout << endl;
		while (CNIC_check == false) {
			cout << "Please enter your CNIC: " << endl;
			cin >> CNIC;
			CNIC_check = true;
			if (strlen(CNIC) < 13) {
				CNIC_check = false;
				cout << "Your CNIC must be atleast 13 characters " << endl;

			}
			cout << endl;
		}
		while (password_check == false) {
			cout << "Please enter password" << endl;
			cout << "Password must be 8 characters long and the use of a minimum of one special character, uppercase, lowercase, and the numeric digit is a must." << endl;
			cin >> set_Password;

			if (strlen(set_Password) < 8) {
				password_check = false;
				cout << "Your password must be atleast 8 characters long" << endl;
				continue;
			}
			for (int i = 0; i < 9; i++) {
				if ((set_Password[i] >= 65 && set_Password[i] <= 90) || (set_Password[i] >= 97 && set_Password[i] <= 122) || (set_Password[i] >= 32 && set_Password[i] <= 47) ||
					(set_Password[i] >= 58 && set_Password[i] <= 64) ||
					(set_Password[i] >= 91 && set_Password[i] <= 96) ||
					(set_Password[i] >= 123 && set_Password[i] <= 126)) {
					password_check = true;
					continue;
				}


			}

		}
		cout << endl;
		cout << "Please enter the hospital name." << endl;
		cin >> hospital;
		cout << endl;
		cout << "Please enter your availability hours, you are available from: " << endl;
		cin >> availabilty_from;
		cout << endl;
		cout << "Available hours, you are available to:" << endl;
		cin >> availability_to;
		cout << endl;
		cout << "Please enter your location." << endl;
		cin >> location;
		cout << endl;
		cout << "Please enter your years of experience." << endl;
		cin >> years_of_experience;
		cout << endl;
		cout << "Please enter your checkup rate." << endl;
		cin >> rates;
		cout << endl;
		cout << "Doctor successfully registered" << endl;
		//Appointments[10] = new Appointment[availability_to - availabilty_from];
		write("Doctor.dat", *this);
	}


	 virtual void Login() {
		string user, pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << "Enter Password: " << endl;
		cin >> pass;
		read("doctor.dat", user, pass);
	}

	void Display() {

		

		cout << "Name of the doctor: " << username << endl;
		cout << "CNIC of the doctor: " << CNIC << endl;
		cout << "Speciality of the doctor: " << speciality << endl;
		cout << "Hospital name of the doctor: " << hospital << endl;
		cout << "Location: " << location << endl;
		cout << "Doctor Availability hours: " << availabilty_from<<"-"<<availability_to<<endl;
		cout << "Charges of the doctor: " << rates << endl;
		cout << endl;
	}

	void write(string file_name, Doctor obj)
	{

		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();

	}

	void read(string file_name, string u, string p)
	{
		Doctor obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_Password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					break;
				}
			}
		}

		fin.close();

	}

	void read(string file_name, string h)
	{
		Doctor obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.hospital);
			string b(obj.speciality);
			string c(obj.location);
			if (a == h) {
				obj.Display();
				
			}
			else if (b == h) {
			 obj.Display();
			}
			else if (c == h) {
				obj.Display();
			}
		}

		fin.close();

	}

	void read(string file_name) {
		Doctor obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			obj.Display();
		}
		fin.close();
	
	}

};

class Orthopedic : public Doctor {
public:
	Orthopedic() {
		rates = 0;
		years_of_experience = 0;
	}

	Orthopedic(string u) {
		strcpy_s(username, u.c_str());
	}

	Orthopedic(int avail_from,int avail_to, string loc, int fee, int years) {
		availabilty_from = avail_from;
		availability_to = avail_to;
		strcpy_s(location, loc.c_str());
		rates = fee;
		years_of_experience = years;
	}

	void Register() {

	}

	void Login() {
		string user, pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> pass;
		cout << endl;
		read("doctor.dat", user, pass);
	}

	void Display() {
		cout << "Username: " << username << endl;
		//cout<<"Specilaity"<<
		cout << "Password: " << set_Password << endl;
		cout << "CNIC: " << CNIC << endl;
		//cout << "Timings: " << timings << endl;
		cout << "Location: " << location << endl;
		cout << "Years of experience: " << years_of_experience << endl;
		cout << "Checkup rate: " << rates << endl;
	}

	void write(string file_name, Orthopedic obj)
	{
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	void read(string file_name, string u, string p)
	{
		Orthopedic obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_Password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					break;
				}
				else {
					cout << "Wrong Credentials! Enter again" << endl;
					Login();
				}
			}
		}

		fin.close();

	}

};

class Dermatologist : public Doctor {
public:
	Dermatologist() {
		rates = 0;
		years_of_experience = 0;
	}

	Dermatologist(string user) {
		strcpy_s(username, user.c_str());
	}

	Dermatologist(int avail_from, int avail_to, string loc, int fee, int years) {
		availabilty_from = avail_from;
		availability_to = avail_to;
		strcpy_s(location, loc.c_str());
		rates = fee;
		years_of_experience = years;
	}

	void Register() {
	}

	void Login() {
		string user, pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> pass;
		cout << endl;
		read("doctor.dat", user, pass);
	}
	

	void Display() {
		cout << "Username: " << username << endl;
		cout << "Password: " << set_Password << endl;
		cout << "CNIC: " << CNIC << endl;
		//cout << "Timings: " << timings << endl;
		cout << "Location: " << location << endl;
		cout << "Years of experience: " << years_of_experience << endl;
		cout << "Checkup rate: " << rates << endl;
	}

	
	void write(string file_name, Orthopedic obj)
	{
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	void read(string file_name, string u, string p)
	{
		Dermatologist obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_Password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					break;
				}
				else {
					cout << "Wrong Credentials! Enter again" << endl;
					Login();
				}
			}
		}

		fin.close();

	}


};

class Oncologist : public Doctor {
public:
	Oncologist() {
		rates = 0;
		years_of_experience = 0;
	}

	Oncologist(string un) {
		strcpy_s(username, un.c_str());
	}

	Oncologist(int avail_from, int avail_to, string loc, int fee, int years) {
		availabilty_from = avail_from;
		availability_to = avail_to;
		//strcpy_s(timings, timing.c_str());
		strcpy_s(location, loc.c_str());
		rates = fee;
		years_of_experience = years;
	}

	void Register() {
	}

	void Display() {
		cout << "Username: " << username << endl;
		cout << "Password: " << set_Password << endl;
		cout << "CNIC: " << CNIC << endl;
		//cout << "Timings: " << timings << endl;
		cout << "Location: " << location << endl;
		cout << "Years of experience: " << years_of_experience << endl;
		cout << "Checkup rate: " << rates << endl;
	}

	void Login() {
		string user, pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> pass;
		cout << endl;
		read("doctor.dat", user, pass);
	}

	void write(string file_name, Orthopedic obj)
	{
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	void read(string file_name, string u, string p)
	{
		Oncologist obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_Password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					break;
				}
				else {
					cout << "Wrong Credentials! Enter again" << endl;
					Login();
				}
			}
		}

		fin.close();

	}

};

class Gynecologist : public Doctor {
public:
	Gynecologist() {
		rates = 0;
		years_of_experience = 0;
	}

	Gynecologist(string n) {
		strcpy_s(username, n.c_str());
	}

	Gynecologist(int avail_from, int avail_to, string loc, int fee, int years) {
		availabilty_from = avail_from;
		availability_to = avail_to;
		//strcpy_s(timings, timing.c_str());
		strcpy_s(location, loc.c_str());
		rates = fee;
		years_of_experience = years;
	}

	void Register() {
	}

	void Display() {
		cout << "Username: " << username << endl;
		cout << "Password: " << set_Password << endl;
		cout << "CNIC: " << CNIC << endl;
		//cout << "Timings: " << timings << endl;
		cout << "Location: " << location << endl;
		cout << "Years of experience: " << years_of_experience << endl;
		cout << "Checkup rate: " << rates << endl;
	}

	void Login() {
		string user, pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> pass;
		cout << endl;
		read("doctor.dat", user, pass);
	}

	void write(string file_name, Orthopedic obj)
	{
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	void read(string file_name, string u, string p)
	{
		Gynecologist obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_Password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					break;
				}
				else {
					cout << "Wrong Credentials! Enter again" << endl;
					Login();
				}
			}
		}

		fin.close();

	}


};

class Neurologist : public Doctor {
public:
	Neurologist() {
		rates = 0;
		years_of_experience = 0;
	}

	Neurologist(string u) {
		strcpy_s(username, u.c_str());
	}

	Neurologist(int avail_from, int avail_to, string loc, int fee, int years) {
		availabilty_from = avail_from;
		availability_to = avail_to;
		//strcpy_s(timings, timing.c_str());
		strcpy_s(location, loc.c_str());
		rates = fee;
		years_of_experience = years;
	}

	void Register() {
	}

	void Display() {
		cout << "Username: " << username << endl;
		cout << "Password: " << set_Password << endl;
		cout << "CNIC: " << CNIC << endl;
		//cout << "Timings: " << timings << endl;
		cout << "Location: " << location << endl;
		cout << "Years of experience: " << years_of_experience << endl;
		cout << "Checkup rate: " << rates << endl;
	}


	void Login() {
		string user, pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> pass;
		cout << endl;
		read("doctor.dat", user, pass);
	}

	void write(string file_name, Orthopedic obj)
	{
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	void read(string file_name, string u, string p)
	{
		Neurologist obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_Password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					break;
				}
				else {
					cout << "Wrong Credentials! Enter again" << endl;
					Login();
				}
			}
		}

		fin.close();

	}

};

class Physician : public Doctor {
public:
	Physician() {
		rates = 0;
		years_of_experience = 0;
	}

	Physician(string u) {
		strcpy_s(username, u.c_str());
	}

	Physician(int avail_from, int avail_to, string loc, int fee, int years) {
		availabilty_from = avail_from;
		availability_to = avail_to;
		//strcpy_s(timings, timing.c_str());
		strcpy_s(location, loc.c_str());
		rates = fee;
		years_of_experience = years;
	}

	void Register() {
	}

	void Display() {
		cout << "Username: " << username << endl;
		cout << "Password: " << set_Password << endl;
		cout << "CNIC: " << CNIC << endl;
		//cout << "Timings: " << timings << endl;
		cout << "Location: " << location << endl;
		cout << "Years of experience: " << years_of_experience << endl;
		cout << "Checkup rate: " << rates << endl;
	}

	void Login() {
		string user, pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> pass;
		cout << endl;
		read("doctor.dat", user, pass);
	}

	void write(string file_name, Orthopedic obj)
	{
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	void read(string file_name, string u, string p)
	{
		Physician obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_Password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					break;
				}
				else {
					cout << "Wrong Credentials! Enter again" << endl;
					Login();
				}
			}
		}

		fin.close();

	}


};
