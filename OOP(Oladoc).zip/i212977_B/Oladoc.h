#pragma once
#include<iostream>
#include<string>
#include"User.h"
#include"Admin.h"
#include"Appointment.h"
#include"DateTime.h"
#include"Doctor.h"
#include"Patient.h"
using namespace std;
class Oladoc {
	private:
		User* users[3];
		Doctor* doc;
public:
	Oladoc() {
		for (int i = 0; i < 3; i++) {
			this->users[i] = new User[i];
		}
	}

	void Display(){

	string speciality;
	string name, n;
	Admin a("Oladoc", "123456");
	Patient p(n);
	Doctor d;
	a.write("admin.dat", a);
	//a.read("out.dat");
	int rpt;
	int choice, select;
	int numb;
	do {
		cout << "Welcome to Oladoc Health Care system!" << endl;
		cout << "Select options from the following menu: " << endl;
		cout << "1. Login as Admin" << endl;
		cout << "2. Register as Doctor" << endl;
		cout << "3. Login as Doctor" << endl;
		cout << "4. Register as Patient" << endl;
		cout << "5. Login as Patient" << endl;
		//cout << "6. Logout" << endl;
		cin >> choice;
		system("CLS");
		switch (choice)
		{
		case 1:
			cout << "Enter admin credentials" << endl;
			cout << endl;
			a.Login();
			cout << "Select from the following menu: " << endl;
			cout << "1. View Doctors' Data" << endl;
			cout << "2. Edit Doctors' Data" << endl;
			cout << "3. Add Doctor" << endl;
			cout << "4. Delete Doctor" << endl;
			cout << "5. View Patients' Data" << endl;
			cout << "6. View all appointments" << endl;
			cout << "7. Update appointment" << endl;
			cout << "8. Cancel appointment" << endl;
			cout << "9. Logout" << endl;
			cin >> select;
			if (select == 1) {
				a.view();
			}
			else if (select == 2) {
				a.Edit();
			}
			else if (select == 3) {
				a.Add();
			}
			else if (select == 4) {
				a.Delete();
			}
			else if (select == 5) {
				a.view_Patient();
			}
			else if (select == 6) {
				a.appointment_details();
			}
			else if (select == 7) {
				a.UpdateAppointment();
			}
			else if (select == 8) {
				a.CancelAppointment();
			}
			else if (select == 9) {
				a.Logout();
			}
			break;
		case 2:
			cout << "Enter Doctor credentials" << endl;
			cout << endl;
			d.Register();
			break;
		case 3:
			cout << "Welcome to login as a doctor" << endl;
			cout << endl;
			cout << "Please enter doctor credentials to login" << endl;
			cout << endl;
			cout << "Enter your speciality\n";
			cin >> speciality;
			
			cout << endl;
			if (speciality == "Orthopedic") {
				
				doc = new Orthopedic;
				doc->Login();
				cout << "Select from the following menu:" << endl;
				cout << "1. View all Appointments" << endl;
				cout << "2. Change availability hours" << endl;
				cout << "3. Change checkup charges" << endl;
				cout << "4. Edit Profile" << endl;
				cout << "5. Logout" << endl;
				cin >> numb;
				cout << endl;
				if (numb == 1) {

				}
				else if (numb == 2) {

				}
				else if (numb == 3) {

				}
				else if (numb == 4) {

				}
				else if (numb == 5) {
					a.Logout();
				}
			}
			else if (speciality == "Dermatologist") {
				doc = new Dermatologist;
				doc->Login();
				cout << "Select from the following menu:" << endl;
				cout << "1. View all Appointments" << endl;
				cout << "2. Change availability hours" << endl;
				cout << "3. Change checkup charges" << endl;
				cout << "4. Edit Profile" << endl;
				cout << "5. Logout" << endl;
				cin >> numb;
				cout << endl;
				if (numb == 1) {

				}
				else if (numb == 2) {

				}
				else if (numb == 3) {

				}
				else if (numb == 4) {

				}
				else if (numb == 5) {
					a.Logout();
				}
			}
			else if (speciality == "Oncologist") {
				Doctor* d3 = new Oncologist;
				d3->Login();
				cout << "Select from the following menu:" << endl;
				cout << "1. View all Appointments" << endl;
				cout << "2. Change availability hours" << endl;
				cout << "3. Change checkup charges" << endl;
				cout << "4. Edit Profile" << endl;
				cout << "5. Logout" << endl;
				cin >> numb;
				cout << endl;
				if (numb == 1) {

				}
				else if (numb == 2) {

				}
				else if (numb == 3) {

				}
				else if (numb == 4) {

				}
				else if (numb == 5) {
					a.Logout();
				}
			}
			else if (speciality == "Gynecologist") {
				Doctor* d4 = new Gynecologist;
				d4->Login();
				cout << "Select from the following menu:" << endl;
				cout << "1. View all Appointments" << endl;
				cout << "2. Change availability hours" << endl;
				cout << "3. Change checkup charges" << endl;
				cout << "4. Edit Profile" << endl;
				cout << "5. Logout" << endl;
				cin >> numb;
				cout << endl;
				if (numb == 1) {

				}
				else if (numb == 2) {

				}
				else if (numb == 3) {

				}
				else if (numb == 4) {

				}
				else if (numb == 5) {
					a.Logout();
				}
			}
			else if (speciality == "Neurologist") {
				Doctor* d5 = new Neurologist;
				d5->Login();
				cout << "Select from the following menu:" << endl;
				cout << "1. View all Appointments" << endl;
				cout << "2. Change availability hours" << endl;
				cout << "3. Change checkup charges" << endl;
				cout << "4. Edit Profile" << endl;
				cout << "5. Logout" << endl;
				cin >> numb;
				cout << endl;
				if (numb == 1) {

				}
				else if (numb == 2) {

				}
				else if (numb == 3) {

				}
				else if (numb == 4) {

				}
				else if (numb == 5) {
					a.Logout();
				}
			}
			else if (speciality == "Physician") {
				Doctor* d6 = new Physician;
				d6->Login();
				cout << "Select from the following menu:" << endl;
				cout << "1. View all Appointments" << endl;
				cout << "2. Change availability hours" << endl;
				cout << "3. Change checkup charges" << endl;
				cout << "4. Edit Profile" << endl;
				cout << "5. Logout" << endl;
				cin >> numb;
				cout << endl;
				if (numb == 1) {

				}
				else if (numb == 2) {

				}
				else if (numb == 3) {

				}
				else if (numb == 4) {

				}
				else if (numb == 5) {
					a.Logout();
				}
			}
			break;
		case 4:
			cout << "Please enter patient details to register" << endl;
			cout << endl;
			p.Register();
			break;
		case 5:
			int num;
			cout << "Welcome to Login as a patient" << endl;
			cout << endl;
			cout << "Please enter patient credentials to login" << endl;
			cout << endl;
			p.Login();

			cout << "Select from the following menu" << endl;
			cout << "1. Book an appointment" << endl;
			cout << "2. Cancel your appointment" << endl;
			cout << "3. View appointment" << endl;
			cout << "4. Logout" << endl;
			cin >> num;
			cout << endl;
			if (num == 1) {
				p.bookappointment();
				
				break;
			}
			else if (num == 2) {

			}
			else if (num == 3) {
				p.Details();
			}
			else if (num == 4) {
				a.Logout();
			}
			break;
		default:
			cout << "Wrong menu choosed! Select Again." << endl;
			Display();
			break;
		}

		cout << "If you want to perform any other action please press 1, press any key to exit" << endl;
		cin >> rpt;
		system("CLS");
	} while (rpt == 1);



}
};
