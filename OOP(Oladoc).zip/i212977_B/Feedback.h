#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include"Patient.h"
#include"DateTime.h"
#include"Doctor.h"
using namespace std;
class Feedback {
private:
	string feedback;
	Patient* patients;
	Datetime* time;
	Doctor* doc;
public:
	Feedback() {
		feedback = '\0';
		/*patients = NULL;
		time = NULL;
		doc = NULL;*/
	}
	Feedback(Patient* p, Datetime* dt, Doctor* d) {
		patients = p;
		time = dt;
		doc = d;
	}
	void give_feedback() {
		cout << "Please enter feedback" << endl;
		cin >> feedback;
	}

	void Display() {

		cout << "The time of the feedback is: " << time->getDay() << "/" << time->getmonth() << "/" << time->getYear() << "\t" << time->gethour() << ":" << time->getmin() << endl;
	}

};