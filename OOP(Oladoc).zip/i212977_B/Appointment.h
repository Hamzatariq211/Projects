
#pragma once
#include<string>
#include<ctime>
#include<iostream>
#include<fstream>
#include"Payment.h"
#include"DateTime.h"
#include"Doctor.h"
using namespace std;

class Appointment {
protected:
	char doctor_name[20];
	char day[30], appointment_mode[100];
	char patient_CNIC[100], doc_cnic[100], patient_name[100];
	int starttime, finish_time;
	Datetime* date;
	Payment* amount;
public:
	Appointment() {
		doctor_name[20] = { '\0' };
		day[30] = { '\0' };
		starttime = 0;
		patient_CNIC[100] = {'\0'};
		doc_cnic[100] = { '\0' };
		patient_name[100] = { '\0' };
		appointment_mode[100] = { '\0' };
		this->date = new Datetime();
		this->amount = new Payment();
	}

	void set_docname(string doc) {
		strcpy_s(doctor_name, doc.c_str());
	}

	string get_docname() {
		return  doctor_name;
	}

	void set_docCnic(string doc_Cnic) {
		strcpy_s(doc_cnic, doc_Cnic.c_str());
	}

	string get_docCnic() {
		return doc_cnic;
	}

	void set_Patientname(string pat_name) {
		strcpy_s(patient_name, pat_name.c_str());
	}

	string get_Patientname() {
		return patient_name;
	}

	void set_PatientCnic(string pat_cnic) {
		strcpy_s(patient_CNIC, pat_cnic.c_str());
	}

	string get_PatientCnic() {
		return patient_CNIC;
	}

	void set_Appointmentmode(string mode) {
		strcpy_s(appointment_mode, mode.c_str());
	}

	string get_Appointmentmode() {
		return appointment_mode;
	}

	void set_Day(string d) {
		strcpy_s(day, d.c_str());
	}

	string get_Day() {
		return day;
	}

	void set_starttime(int time) {
		starttime = time;
	}

	int get_starttime() {
		return starttime;
	}

	void set_finishtime(int fintime) {
		finish_time = fintime;
	}

	int get_finishtime() {
		return finish_time;
	}
	

	void write(string file_name, Appointment obj)
	{

		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();

	}

	void read(string file_name, string doc_Cnic, string doc_name, string patient_cnic, string patient_Name, string app_mode, string Day, string Time){
		
		Appointment obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.doc_cnic);
			string b(obj.doctor_name);
			string c(obj.patient_CNIC);
			string d(obj.patient_name);
			string e(obj.appointment_mode);
			string f(obj.day);
			
			
			
		}

		fin.close();

	}

	void appointmentDetails() {
		cout << "Doctor Name: " << doctor_name << endl;
		cout << "Doctor CNIC: " << doc_cnic << endl;
		cout << "Patient Name: " << patient_name << endl;
		cout << "Patient CNIC: " << patient_CNIC << endl;
		cout << "Mode of appointment: " << appointment_mode << endl;
		cout << "Day of appointment: " << day << endl;
		cout << "Time of appointment: " << time << endl;
		//write("appointment.dat", *this);
	}

};

class Vedioconsultation : public Appointment {
public:
	Vedioconsultation() {
		
		doctor_name[20] = { '\0' };
		day[30] = { '\0' };
		patient_CNIC[100] = { '\0' };
		doc_cnic[100] = { '\0' };
		patient_name[100] = { '\0' };
		appointment_mode[100] = { '\0' };
		this->date = new Datetime();
		this->amount = new Payment();
	}

	
};

class In_Person : public Appointment {
public:

};