#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<cstring>
using namespace std;
#include"User.h"
#include"Appointment.h"
class Patient : public User {
private:
	Appointment* appoint[100];
	char CNIC[20], set_password[20]{NULL}, re_enterpassword[20];
	bool cnic_check=false, correctpassword=false;
	char hospital_name[100], specialization[100], city[100];
	char doc_name[100]={'\0'}, doc_CNIC[100]={'\0'}, appointment_mode[100]={'\0'}, day[20]={'\0'};
	int time_from=0, time_to=0;

public:
	Patient() {

		cnic_check = false;
		correctpassword = false;
		
	}
	Patient(string pass,  string Name) {
		strcpy_s(username,Name.c_str());
		strcpy_s(set_password, pass.c_str());
		 
	}
	Patient(string user_name, string Password, string cnic, string Set_Password) : User(user_name, Password) {
		
		strcpy_s(username, user_name.c_str());
		strcpy_s(CNIC, cnic.c_str());
		strcpy_s(set_password, Set_Password.c_str());


	}
	Patient(string u) {
		strcpy_s(username, u.c_str());
	}

	Patient(Appointment* app[100]) {
		for (int i = 0; i < 100; i++) {
			Appointment* app = new Appointment[i];
		}
	}

	void Register() {
		//bool  flag1=false, flag2=false, flag3=false;
		cout << "Please enter your name: " << endl;
		cin >> username;
		cout << endl;
		while (cnic_check == false) {
			cout << "Please enter your CNIC: " << endl;
			cin >> CNIC;
			cout << endl;
			cnic_check = true;
			if (strlen(CNIC) < 13) {
				cnic_check = false;
				cout << "Your CNIC must be atleast 13 characters " << endl;

			}
			cout << endl;
		}
		while (correctpassword == false) {
			cout << "Please enter password" << endl;
			cout << "Password must be 8 characters long and the use of a minimum of one special character, uppercase, lowercase, and the numeric digit is a must." << endl;
			cin >> set_password;

			if (strlen(set_password) < 8) {
				correctpassword = false;
				cout << "Your password must be atleast 8 characters long" << endl;
				continue;
			}
			for (int i = 0; i < 9; i++) {
				if ((set_password[i] >= 65 && set_password[i] <= 90) || (set_password[i] >= 97 && set_password[i] <= 122) || (set_password[i] >= 32 && set_password[i] <= 47) ||
					(set_password[i] >= 58 && set_password[i] <= 64) ||
					(set_password[i] >= 91 && set_password[i] <= 96) ||
					(set_password[i] >= 123 && set_password[i] <= 126)) {
					correctpassword = true;
					continue;
				}


			}

		}
		cout << endl;
		cout << "Patient successfully registered" << endl;
		write("Patient.dat", *this);
	}

	void write(string file_name, Patient obj)
	{
		
			ofstream fout(file_name, ios::binary | ios::app);
			fout.write((char*)&obj, sizeof(obj));
			fout.close();
		
	}


	void write(string file_name, Appointment obj)
	{

		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();

	}

	void read(string file_name, string u, string p)
	{
		Patient obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			string a(obj.username);
			string b(obj.set_password);
			if (a == u) {
				if (p == b) {

					cout << "Login Successful: " << endl;
					cout << endl;
					break;
				}
			}
		}

		fin.close();

	}
    
	void read(string file_name) {
		Patient obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			obj.Display();
		}
		fin.close();
	}

	void Login() 
	{
		string user,pass;
		cout << "Enter Username:  " << endl;
		cin >> user;
		cout << endl;
		cout << "Enter Password: " << endl;
		cin >> pass;
		cout << endl;
		read("Patient.dat", user, pass);
		
		
	}

	void Display() {
		cout << "Username: " << username << endl;
		cout << "password: " << set_password << endl;
	}


	void search_doc() {
		int choice;
		cout << "Welcome to Search Doctor" << endl;
		cout << endl;
		cout << "Please select from the following menu: " << endl;
		cout << endl;
		cout << "1. Enter hospital name to seach doctor." << endl;
		cout << "2. Enter specialization of the doctor to search. " << endl;
		cout << "3. Enter the location where you want to find doctors." << endl;
		cin >> choice;
		cout << endl;
		Doctor d;
		switch (choice) {
		case 1:
			cout << "Please enter the name of the Hospital" << endl;
			cin >> hospital_name;
			cout << endl;
			d.read("doctor.dat",hospital_name);
			break;
		case 2:
			cout << "Please enter the specialization of the doctor." << endl;
			cin >> specialization;
			cout << endl;
			d.read("doctor.dat", specialization);
			break;
		case 3:
			cout << "Please enter the location where you want to find the doctor." << endl;
			cin >> city;
			cout << endl;
			d.read("doctor.dat", city);
			break;
		default:
			cout << "Invalid input" << endl;
			cout << endl;
			break;
		}
	}
	void bookappointment() {
		int time;
		Appointment app;
		cout << "Welcome to Oladoc's Book Appointment page!" << endl;
		cout << endl;
		cout << "Firstly, you want to search doctor you want to book an appointment with." << endl;
		cout << endl;
		search_doc();
		cout << endl;
		cout << "Please enter your name" << endl;
		cin >> username;
		app.set_Patientname(username);
		cout << endl;
		cout << "Please enter your CNIC" << endl;
		cin >> CNIC;
		app.set_PatientCnic(CNIC);
		cout << endl;
		cout << "Please enter Doctor's name you want to book an appointment with." << endl;
		cin >> doc_name;
		app.set_docname(doc_name);
		cout << endl;
		cout << "Please enter Doctor's CNIC you want to book an appointment with." << endl;
		cin >> doc_CNIC;
		app.set_docCnic(doc_CNIC);
		cout << endl;
		cout << "Please enter the mode of appointment" << endl;
		cin >> appointment_mode;
		app.set_Appointmentmode(appointment_mode);
		cout << endl;
		cout << "Please enter the day of the appointment" << endl;
		cin >> day;
		app.set_Day(day);
		cout << endl;
		cout << "Please enter the time of the appointment" << endl;
		cin >> time_from;
		app.set_starttime(time_from);
		cout << endl;
		Doctor doc;
		ifstream fin("doctor.dat", ios::binary);
		while (fin.read((char*)&doc, sizeof(doc)))
		{
			if (doc.get_CNIC() == doc_CNIC) {
				cout << "The doctor you have entered is available from " << doc.get_availfrom() << " to " << doc.get_availto() << endl;
				break;
			}
		}
		fin.close();

		cout << "Please enter your time for appointment" << endl;
		cin >> time;
		while (time<doc.get_availfrom() || time>doc.get_availto()) {
			cout << "Invalid time entered, please enter time within the availability hours of the doctor" << endl;
			cin >> time;
		}
		bool check = check_appointment("appointment.dat", time);
		while (check == 1) {
			cout << "Please enter time within the availability hours of the doctor" << endl;
			cin >> time;
			cout << endl;
			check = check_appointment("appointment.dat", time);
		}
		write_record("appointment.dat", app);
		cout << "Appointment booked successfully" << endl;
	}

	void write_record(string file_name, Appointment obj) {
		ofstream fout(file_name, ios::binary | ios::app);
		fout.write((char*)&obj, sizeof(obj));
		fout.close();
	}

	bool check_appointment(string file_name, int t) {
		Appointment obj;
		ifstream fin(file_name, ios::binary);
		while (fin.read((char*)&obj, sizeof(obj)))
		{
			if (obj.get_starttime() >= t && obj.get_starttime() <= 60) {
				return true;
			}
		}
		fin.close();
		return false;
	}

	void Details() {
		cout << "Patient's Name: " << username<<endl;
		cout << endl;
		cout << "Patient's CNIC: " << CNIC << endl;		
		cout << endl;
		cout << "Doctor's name: " << doc_name << endl;
		cout << endl;
		cout << "Doctor's CNIC: " << doc_CNIC << endl;
		cout << endl;
		cout << "Mode of appointment: " <<appointment_mode<< endl;
		cout << endl;
		cout << "Appointment Day: " << day << endl;
		cout << endl;
		cout << "Time of the appointment" << time <<endl;
		
	}
};
