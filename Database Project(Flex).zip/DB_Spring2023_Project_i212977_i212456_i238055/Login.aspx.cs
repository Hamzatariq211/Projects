﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        string username = TextBox1.Text;
        string password = TextBox2.Text;
       // string username = Request.Form["TextBox1.Text"];
        //string password = Request.Form["TextBox2.Text"];
        string query = "Select username, password from student where username = '" + username  + "' AND password = '"+ password + "'";
        cm = new SqlCommand(query, conn);

      


        SqlDataReader res = cm.ExecuteReader();
        

        if (!res.HasRows)
        {
             Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "Please enter a valid username or Password;");
            cm.Dispose();
            conn.Close();
        }
        else
        {

            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "alert('Successfully logged in');");
            cm.Parameters.AddWithValue("@username", username);
            cm.Parameters.AddWithValue("@password", password);
            //cm.ExecuteNonQuery();
            Response.Redirect("Home.aspx?username=" + username + "&password=" + password);

        }




    }




    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        string un = TextBox1.Text;
        string pass = TextBox2.Text;
        string query = "Select * from Admin_Login where username = '" + un + "' AND password ='" + pass + " ' ";
        cm = new SqlCommand(query, conn);

        SqlDataReader res = cm.ExecuteReader();

        if (!res.HasRows)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "Please enter a valid username or Password;");
            cm.Dispose();
            conn.Close();
        }
        else
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "alert('Successfully logged in');");
            //cm.ExecuteNonQuery();
            Response.Redirect("Academic Officer.aspx");
            // Response.Redirect("Home.aspx");
        }

    }

   

    protected void Button2_Click1(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        string username = TextBox1.Text;
        string password = TextBox2.Text;
        string query = "Select username, pass from Faculty where username = '" + username + "' AND pass ='" + password + " ' ";
        cm = new SqlCommand(query, conn);

        SqlDataReader res = cm.ExecuteReader();

        if (!res.HasRows)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "Please enter a valid username or Password;");
            cm.Dispose();
            conn.Close();
        }
        else
        {
            cm.Parameters.AddWithValue("@username", username);
            cm.Parameters.AddWithValue("@password", password);
            //cm.ExecuteNonQuery();
            Response.Redirect("Faculty_interface.aspx?username=" + username + "&password=" + password);
            Page.ClientScript.RegisterStartupScript(this.GetType(), "scriptkey", "alert('Successfully logged in');");
            //cm.ExecuteNonQuery();
            //Response.Redirect("Faculty_interface.aspx");
           // Response.Redirect("Home.aspx");
        }
          
    }
}