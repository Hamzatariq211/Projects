﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_addStu : System.Web.UI.Page
{

    private DataTable GetStudentInfo()
    {
        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT * FROM student"; // Modify the query according to your database schema
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable studentInfo = GetStudentInfo();
            if (studentInfo.Rows.Count > 0)
            {
                // Create a new table to hold the student data
                Table table = new Table();
               

                // Iterate through each row in the DataTable and create a new row for each one
                foreach (DataRow row in studentInfo.Rows)
                {
                    // Create a new row for the current student
                    TableRow dataRow = new TableRow();

                    // Add a cell for the Roll No
                    TableCell rollNoCell = new TableCell();
                    Label rollNoLabel = new Label();
                    rollNoLabel.Text = row["stuID"].ToString();
                    rollNoCell.Controls.Add(rollNoLabel);
                    dataRow.Cells.Add(rollNoCell);

                    // Add a cell for the Name
                    TableCell nameCell = new TableCell();
                    Label nameLabel = new Label();
                    nameLabel.Text = row["Fname"].ToString() + " " + row["Lanme"].ToString();
                    nameCell.Controls.Add(nameLabel);
                    dataRow.Cells.Add(nameCell);

                    // Add a cell for the Batch
                    TableCell batchCell = new TableCell();
                    Label batchLabel = new Label();
                    batchLabel.Text = row["batch"].ToString(); // Replace with the actual column name
                    batchCell.Controls.Add(batchLabel);
                    dataRow.Cells.Add(batchCell);

                    // Add a cell for the Degree
                    TableCell degreeCell = new TableCell();
                    Label degreeLabel = new Label();
                    degreeLabel.Text = row["degree"].ToString(); // Replace with the actual column name
                    degreeCell.Controls.Add(degreeLabel);
                    dataRow.Cells.Add(degreeCell);

                    // Add a cell for the Phone
                    TableCell phoneCell = new TableCell();
                    Label phoneLabel = new Label();
                    phoneLabel.Text = row["phoneNo"].ToString(); // Replace with the actual column name
                    phoneCell.Controls.Add(phoneLabel);
                    dataRow.Cells.Add(phoneCell);

                    // Add the new row to the table
                    table.Rows.Add(dataRow);
                }

                // Add the table to the page
                this.Controls.Add(table);
            }
        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Academic Officer.aspx");
    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Allocate_courses.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_Offercour.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_manageSections.aspx");
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        string studentID = TextBox1.Text.Trim(); // get the student ID from the textbox

        DataTable studentInfo = GetStudentInfo(); // retrieve all student info from the database

        DataRow[] matchingRows = studentInfo.Select("stuID = '" + studentID + "'"); // filter the rows to find the ones with matching student ID

        if (matchingRows.Length > 0)
        {
            DataRow row = matchingRows[0]; // retrieve the first matching row

            // populate the labels with the student info
            lblRollNo.Text = row["stuID"].ToString();
            Name.Text = row["Fname"].ToString() + " " + row["Lanme"].ToString();
            Batch.Text = row["batch"].ToString();
            Degree.Text = row["degree"].ToString();
            Phone.Text = row["phoneNo"].ToString();

            // display the record found message
            lblSearchResult.Text = "Record found!";
         
        }
        else
        {
            // clear the labels
            lblRollNo.Text = "";
            Name.Text = "";
            Batch.Text = "";
            Degree.Text = "";
            Phone.Text = "";

            // display the no record found message
            lblSearchResult.Text = "No record found.";
           
        }
    }
}