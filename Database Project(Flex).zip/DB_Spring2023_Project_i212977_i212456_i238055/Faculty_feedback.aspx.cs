﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
public partial class Faculty_feedback : System.Web.UI.Page
{


    private DataTable GetFeedbackInfo()
    {
       

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT date, score from feedback";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable feedbackInfo = GetFeedbackInfo();
            if (feedbackInfo.Rows.Count > 0)
            {
                DataRow row = feedbackInfo.Rows[0];
                lblDate.Text = row["date"].ToString();
                lblScore.Text = row["score"].ToString();
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_interface.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_setMarks.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_Attendance.aspx");
    }


    private string DataTableToCsv(DataTable dataTable)
    {
        StringBuilder sb = new StringBuilder();

        IEnumerable<string> columnNames = dataTable.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
        sb.AppendLine(string.Join(",", columnNames));

        foreach (DataRow row in dataTable.Rows)
        {
            IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
            sb.AppendLine(string.Join(",", fields));
        }

        return sb.ToString();
    }


    protected void Button4_Click(object sender, EventArgs e)
    {



        // Fetch data from SQL table
        DataTable data = FetchDataFromSQLTable();

        // Generate CSV content from the data
        string csvContent = DataTableToCsv(data);

        // Set response headers for file download
        Response.Clear();
        Response.ContentType = "application/pdf";

        //Response.ContentType = "text/csv";
        Response.AddHeader("Content-Disposition", "attachment; filename=Feedback.csv");

        // Write the CSV content to the response stream
        Response.Write(csvContent);
        Response.End();

    }

    private DataTable FetchDataFromSQLTable()
    {
        // Write code to fetch data from your SQL table and populate a DataTable object.
        DataTable dt = new DataTable();
        // Sample code to populate dt with data from a SQL table
        using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True"))
        {
            SqlCommand command = new SqlCommand("Select * from feedback", connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(dt);
        }
        return dt;
    }


   
}