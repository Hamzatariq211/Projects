﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

public partial class Faculty_setMarks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_interface.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_Attendance.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_feedback.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        string facultyName = Request.Form["name"];
        string courseCode = Request.Form["course"];
        string projectStr = Request.Form["project"];
        string quizzesStr = Request.Form["quizzes"];
        string assignmentsStr = Request.Form["assignments"];
        string midtermStr = Request.Form["midterm"];
        string finalStr = Request.Form["final"];
        int project = int.Parse(projectStr);
        int quizzes = int.Parse(quizzesStr);
        int assignments = int.Parse(assignmentsStr);
        int midterm = int.Parse(midtermStr);
        int final = int.Parse(finalStr);


        // Check if all required fields are filled
        if (string.IsNullOrEmpty(facultyName) || string.IsNullOrEmpty(courseCode) ||
            string.IsNullOrEmpty(projectStr) || string.IsNullOrEmpty(quizzesStr) ||
            string.IsNullOrEmpty(assignmentsStr) || string.IsNullOrEmpty(midtermStr) ||
            string.IsNullOrEmpty(finalStr))
        {
            // Display an error message
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please fill all the required fields.');", true);
        }
        

        // Check if weightages add up to more than 100
        int total = project + quizzes + assignments + midterm + final;
        if (total > 100 || total < 100)
        {
            // Display error message
            Response.Write("<script>alert('The weightages are not equal to 100. Please adjust the values.');</script>");
        }
        else
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
            conn.Open();
            SqlCommand cm;
            string query = "Insert into Marks_distribution (facName, cour_code, project, quiz, assignments, midterm, final) values ('" + facultyName + "' , '" + courseCode + "','" + projectStr + "', '" + quizzesStr + "', '" + assignmentsStr + "', '" + midtermStr + "', '" + finalStr + "')";
            cm = new SqlCommand(query, conn);
            cm.ExecuteNonQuery();
            cm.Dispose();
            conn.Close();
            // Proceed with the form submission
            Response.Redirect("Faculty_setMarks.aspx");
            // Weightages are valid, do further processing
            // ...
        }
      

       

    }


    private string DataTableToCsv(DataTable dataTable)
    {
        StringBuilder sb = new StringBuilder();

        IEnumerable<string> columnNames = dataTable.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
        sb.AppendLine(string.Join(",", columnNames));

        foreach (DataRow row in dataTable.Rows)
        {
            IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
            sb.AppendLine(string.Join(",", fields));
        }

        return sb.ToString();
    }

    private DataTable FetchDataFromSQLTable()
    {
        // Write code to fetch data from your SQL table and populate a DataTable object.
        DataTable dt = new DataTable();
        // Sample code to populate dt with data from a SQL table
        using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True"))
        {
            SqlCommand command = new SqlCommand("Select COUNT(*) as grade_count from Transcript where grade = 'A'", connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(dt);
        }
        return dt;
    }
    protected void Button4_Click1(object sender, EventArgs e)
    {
        // Fetch data from SQL table
        // Fetch data from SQL table
        DataTable data = FetchDataFromSQLTable();

        // Generate CSV content from the data
        string csvContent = DataTableToCsv(data);

        // Set response headers for file download
        Response.Clear();
        Response.ContentType = "application/pdf";

        //Response.ContentType = "text/csv";
        Response.AddHeader("Content-Disposition", "attachment; filename=Grades.csv");

        // Write the CSV content to the response stream
        Response.Write(csvContent);
        Response.End();
    }
}