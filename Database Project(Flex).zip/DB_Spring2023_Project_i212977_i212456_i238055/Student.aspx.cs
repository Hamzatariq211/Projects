﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }



    protected void Button1_Click1(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        SqlCommand cm2;
        string name = TextBox1.Text;
        string un = TextBox2.Text;
        string pass = TextBox3.Text;
        string email = TextBox4.Text;
        string query = "Insert into Register (Name, Username, Password, Email) values ('" + name + "' , '" + un + "','" + pass + "', '" + email + "')";
        //string query2 = "Insert into Login (username, password) values ('" + un + "' , '" + pass + "')";
        cm = new SqlCommand(query, conn);
        //cm2 = new SqlCommand(query2, conn);
        cm.ExecuteNonQuery();
        cm.Dispose();
        //cm2.ExecuteNonQuery();
        //cm2.Dispose();
        conn.Close();
    }





    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        SqlCommand cm2;
        string name = TextBox1.Text;
        string un = TextBox2.Text;
        string pass = TextBox3.Text;
        string email = TextBox4.Text;
        string query = "Insert into Admin_Register (Name, Username, Password, Email) values ('" + name + "' , '" + un + "','" + pass + "', '" + email + "')";
        string query2 = "Insert into Admin_Login (username, password) values ('" + un + "' , '" + pass + "')";
        cm = new SqlCommand(query, conn);
        cm2 = new SqlCommand(query2, conn);
        cm.ExecuteNonQuery();
        cm.Dispose();
        cm2.ExecuteNonQuery();
        cm2.Dispose();
        conn.Close();
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        
    }





    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        SqlCommand cm2;
        string name = TextBox1.Text;
        string un = TextBox2.Text;
        string pass = TextBox3.Text;
        string email = TextBox4.Text;
        string query = "Insert into Faculty_Register (Name, Username, Password, Email) values ('" + name + "' , '" + un + "','" + pass + "', '" + email + "')";
        cm = new SqlCommand(query, conn);
        cm.ExecuteNonQuery();
        cm.Dispose();
        conn.Close();
    }
}