﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Academic_Officer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        Response.Redirect("Admin_addStu.aspx");

    }

    protected void Button2_Click(object sender, EventArgs e)
    {

        Response.Redirect("Allocate_courses.aspx");
     
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_Offercour.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_manageSections.aspx");
    }
}