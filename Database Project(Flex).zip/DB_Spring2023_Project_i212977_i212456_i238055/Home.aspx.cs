﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;


public partial class Home : System.Web.UI.Page
{

    private DataTable GetStudentInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
                                  //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT stuID, Fname, Lanme, batch, degree, section, campus,status, Gender, dob, CNIC, bg, nationality, phoneNo, perAdd, currAdd FROM student where username = '" + username + "' and password = '" + password + "'"; // Modify the query according to your database schema
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable studentInfo = GetStudentInfo();
            if (studentInfo.Rows.Count > 0)
            {
                DataRow row = studentInfo.Rows[0];
                lblRollNo.Text = row["stuID"].ToString();
                lblName.Text = row["Fname"].ToString() + " " + row["Lanme"].ToString();
                lblDegree.Text = row["degree"].ToString(); // Replace with the actual column name
                lblBatch.Text = row["batch"].ToString(); // Replace with the actual column name
                lblSection.Text = row["section"].ToString(); // Replace with the actual column name
                lblCampus.Text = row["campus"].ToString(); // Replace with the actual column name
                lblStatus.Text = row["status"].ToString(); // Replace with the actual column name
                lblGender.Text = row["Gender"].ToString(); // Replace with the actual column name
                lblDOB.Text = row["dob"].ToString(); // Replace with the actual column name
                lblCNIC.Text = row["CNIC"].ToString(); // Replace with the actual column name
                lblBloodGroup.Text = row["bg"].ToString(); // Replace with the actual column name
                lblNationality.Text = row["nationality"].ToString(); // Replace with the actual column name
                lblMobileNumber.Text = row["phoneNo"].ToString(); // Replace with the actual column name
                lblPermanentAddress.Text = row["perAdd"].ToString();
                lblPermanentPhone.Text = row["phoneNo"].ToString();
                lblCurrentAddress.Text = row["currAdd"].ToString();
                lblCurrentPhone.Text = row["phoneNo"].ToString();
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Marks_student.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Attendance.aspx");
    }

    protected void Button3_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Transcript.aspx");
    }

    protected void Button4_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Feedback_students.aspx");
    }
}