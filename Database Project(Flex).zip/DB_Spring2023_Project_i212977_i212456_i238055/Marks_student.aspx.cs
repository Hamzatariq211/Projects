﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

public partial class Marks_student : System.Web.UI.Page
{

    private DataTable GetMarksInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT assignments, project, quiz, midterm, final FROM Marks_distribution"; // Modify the query according to your database schema
            string query2 = "SELECT ass, project, quiz, mid, final from Marks inner join student on Marks.ID = student.stuID";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlCommand com = new SqlCommand(query2, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
               // SqlDataReader reader2 = com.ExecuteReader();
                dataTable.Load(reader);
              //  dataTable.Load(reader2);
            }
        }
        return dataTable;
    }


    private DataTable GetObtainedMarksInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            
            string query = "SELECT ass, project, quiz, mid, final, total from Marks inner join student on Marks.ID = student.stuID";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }


    private DataTable GetAverageMarksInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            string query = "SELECT AVG(ass) as Ass_avg, AVG(project) as pro_avg, AVG(quiz) as quiz_avg, AVG(mid) as mid_avg, AVG(final) as final_avg, AVG(total) as total_avg from Marks inner join student on Marks.ID = student.stuID";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }


    private DataTable GetMinMarksInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            string query = "SELECT MIN(ass) as Ass_min, MIN(project) as pro_min, MIN(quiz) as quiz_min, MIN(mid) as mid_min, MIN(final) as final_min, MIN(total) as total_min from Marks inner join student on Marks.ID = student.stuID";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }



    private DataTable GetMaxMarksInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            string query = "SELECT MAX(ass) as Ass_max, MAX(project) as pro_max, MAX(quiz) as quiz_max, MAX(mid) as mid_max, MAX(final) as final_max, MAX(total) as total_max from Marks inner join student on Marks.ID = student.stuID";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }




    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable MarksInfo = GetMarksInfo();
            if (MarksInfo.Rows.Count > 0)
            {
                DataRow row = MarksInfo.Rows[0];
                Assignments.Text = row["assignments"].ToString();
                Project.Text = row["project"].ToString();
                Quizzes.Text = row["quiz"].ToString();
                MidTerm.Text = row["midterm"].ToString();
                Finals.Text = row["final"].ToString();

                Total1.Text = row["assignments"].ToString();
                Total2.Text = row["project"].ToString();
                Total3.Text = row["quiz"].ToString();
                Total4.Text = row["midterm"].ToString();
                Total5.Text = row["final"].ToString();

            }

            DataTable ObtainedMarks = GetObtainedMarksInfo();
            if (ObtainedMarks.Rows.Count > 0)
            {
                DataRow row = ObtainedMarks.Rows[0];
                Literal2.Text = row["ass"].ToString();
                Literal4.Text = row["project"].ToString();
                Literal6.Text = row["quiz"].ToString();
                Literal8.Text = row["mid"].ToString();
                Literal10.Text = row["final"].ToString();
                Literal12.Text = row["total"].ToString();

            }


            DataTable AverageMarks = GetAverageMarksInfo();
            if (AverageMarks.Rows.Count > 0)
            {
                DataRow row = AverageMarks.Rows[0];
                Literal16.Text = row["ass_avg"].ToString();
                Literal17.Text = row["pro_avg"].ToString();
                Literal18.Text = row["quiz_avg"].ToString();
                Literal19.Text = row["mid_avg"].ToString();
                Literal20.Text = row["final_avg"].ToString();
                Literal21.Text = row["total_avg"].ToString();

            }

            DataTable MINMarks = GetMinMarksInfo();
            if (MINMarks.Rows.Count > 0)
            {
                DataRow row = MINMarks.Rows[0];
                Literal22.Text = row["ass_min"].ToString();
                Literal23.Text = row["pro_min"].ToString();
                Literal24.Text = row["quiz_min"].ToString();
                Literal25.Text = row["mid_min"].ToString();
                Literal26.Text = row["final_min"].ToString();
                Literal27.Text = row["total_min"].ToString();

            }

            DataTable MaxMarks = GetMaxMarksInfo();
            if (MaxMarks.Rows.Count > 0)
            {
                DataRow row = MaxMarks.Rows[0];
                Literal28.Text = row["ass_max"].ToString();
                Literal29.Text = row["pro_max"].ToString();
                Literal30.Text = row["quiz_max"].ToString();
                Literal31.Text = row["mid_max"].ToString();
                Literal32.Text = row["final_max"].ToString();
                Literal33.Text = row["total_max"].ToString();

            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Attendance.aspx");

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Transcript.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Feedback_students.aspx");

    }
}