﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Transcript : System.Web.UI.Page
{



    private DataTable GetGradeInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT grade FROM Transcript"; // Modify the query according to your database schema
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }

    private DataTable GetPointsInfo()
    {
        string username = Request.QueryString["username"];
        string password = Request.QueryString["password"];

        DataTable dataTable = new DataTable();
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        //ConfigurationManager.ConnectionStrings["DBProjectConnection"].ConnectionString;
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            string query = "SELECT points FROM Transcript"; // Modify the query according to your database schema
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dataTable.Load(reader);
            }
        }
        return dataTable;
    }





    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable GradeInfo = GetGradeInfo();
            if (GradeInfo.Rows.Count > 0)
            {
                DataRow row = GradeInfo.Rows[0];
                Literal1.Text = row["grade"].ToString();
                Literal2.Text = row["grade"].ToString();
                Literal3.Text = row["grade"].ToString();
                Literal4.Text = row["grade"].ToString();
                Literal5.Text = row["grade"].ToString();
                Literal6.Text = row["grade"].ToString();
                Literal7.Text = row["grade"].ToString();
                Literal8.Text = row["grade"].ToString();

            }


            DataTable PointsInfo = GetPointsInfo();
            if (PointsInfo.Rows.Count > 0)
            {
                DataRow row = PointsInfo.Rows[0];
                Literal9.Text = row["points"].ToString();
                Literal10.Text = row["points"].ToString();
                Literal11.Text = row["points"].ToString();
                Literal12.Text = row["points"].ToString();
                Literal13.Text = row["points"].ToString();
                Literal14.Text = row["points"].ToString();
                Literal15.Text = row["points"].ToString();
               
            }


            DataTable GradesInfo = GetGradeInfo();
            DataTable PointInfo = GetPointsInfo();

            if (GradesInfo.Rows.Count > 0 && PointInfo.Rows.Count > 0)
            {
                double totalCreditHours = 0;
                double totalGradePoints = 0;
                double totalPoints = 0;

                // Calculate the weighted average of grades and points
                for (int i = 0; i < GradeInfo.Rows.Count; i++)
                {
                    DataRow gradeRow = GradeInfo.Rows[i];
                    DataRow pointsRow = PointsInfo.Rows[i];

                    double creditHours = Convert.ToDouble(3);
                    double points = Convert.ToDouble(pointsRow["points"]);

                    totalCreditHours += creditHours;
                    totalPoints += creditHours * points;
                }

                // Calculate the SGPA and CGPA
                double sgpa = totalPoints / totalCreditHours;

                // Display the SGPA and CGPA on the page
                Literal16.Text = sgpa.ToString("SGPA: 0.00");
            }
        
    }
  }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Marks_student.aspx");

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Attendance.aspx");

    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Feedback_students.aspx");

    }
}