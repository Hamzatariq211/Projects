﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class AddStudent :  System.Web.UI.Page
{

    

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        string stuID = TextBox1.Text;
        string Fname = TextBox2.Text;
        string Lanme = TextBox3.Text;
        string batch = TextBox4.Text;
        string degree = TextBox5.Text;
        string section = TextBox6.Text;
        string campus = TextBox7.Text;
        string status = TextBox8.Text;
        string Gender = TextBox9.Text;
        string dob = TextBox10.Text;
        string CNIC = TextBox11.Text;
        string bg = TextBox12.Text;
        string nationality = TextBox13.Text;
        string phoneNo = TextBox14.Text;
        string perAdd = TextBox15.Text;
        string currAdd = TextBox16.Text;
        string un = TextBox17.Text;
        string pass = TextBox18.Text;

        string query = "Insert into student (stuID, Fname, Lanme, username, batch, degree, section, campus, status, Gender, dob, CNIC, bg, nationality, phoneNo, perAdd, currAdd, password) values ('" + stuID + "' , '" + Fname + "','" + Lanme + "', '" + un + "', '" + batch + "', '" + degree + "', '" + section + "', '" + campus + "', '" + status + "', '" + Gender + "', '" + dob + "', '" + CNIC + "', '" + bg + "', '" + nationality + "', '" + phoneNo + "', '" + perAdd + "', '" + currAdd + "',  '" + pass + "')";
        cm = new SqlCommand(query, conn);
        cm.ExecuteNonQuery();
        cm.Dispose();
        conn.Close();
        Response.Redirect("Admin_addStu.aspx");
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}