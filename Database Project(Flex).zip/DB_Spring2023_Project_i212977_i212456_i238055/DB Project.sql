create database DBProject;
use DBProject;

create table Register(
Name varchar(30) NOT NULL,
Username varchar(20) NOT NULL,
Password varchar(20) NOT NULL,
Email varchar(255) NOT NULL);

select * from Register
drop table Register


create table log
(Activity varchar(40), 
Date date);

CREATE TRIGGER insertions on Register
AFTER INSERT
AS
BEGIN 
INSERT INTO log values
('Student Registered',getdate());
print 'Value inserted successfully'
end
select * from log

create table Admin_Register(
Name varchar(30) NOT NULL,
Username varchar(20) NOT NULL,
Password varchar(20) NOT NULL,
Email varchar(255) NOT NULL);

select * from Admin_Register

CREATE TRIGGER Admin_insertions on Admin_Register
AFTER INSERT
AS
BEGIN 
INSERT INTO log values
('Admin Registered',getdate());
print 'Value inserted successfully'
end
select * from log

create table Faculty_Register(
Name varchar(30) NOT NULL,
Username varchar(20) NOT NULL,
Password varchar(20) NOT NULL,
Email varchar(255) NOT NULL);

select * from Faculty_Register

CREATE TRIGGER faculty_insertions on Faculty_Register
AFTER INSERT
AS
BEGIN 
INSERT INTO log values
('Faculty Registered',getdate());
print 'Value inserted successfully'
end
select * from log

create table Admin_Login(
username varchar(20) NOT NULL,
password varchar(20) NOT NULL);

select * from Admin_Login

CREATE TRIGGER AdminLogin on Admin_Login
AFTER INSERT
AS
BEGIN 
INSERT INTO log values
('Admin logged in',getdate());
print 'Value inserted successfully'
end
select * from log


create table student(
stuID varchar(78),
Fname varchar(40),
Lanme varchar(50),
username varchar(255),
batch varchar(10),
degree varchar(20),
section varchar(5),
campus varchar(30),
status varchar(90),
Gender varchar(30),
dob varchar(40),
CNIC varchar(80),
bg varchar(10),
nationality varchar(100),
phoneNo varchar(100),
perAdd varchar(102),
currAdd varchar(98),
password varchar(100));

BULK INSERT [student]
from 'C:\Users\NITB\Desktop\Students.csv'
with (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FIRSTROW = 2
);
select * from student
drop table student

CREATE TRIGGER studentLogin on student
AFTER INSERT
AS
BEGIN 
INSERT INTO log values
('Student logged in',getdate());
print 'Value inserted successfully'
end
select * from log


create table Admin_info(
ID varchar(10) NOT NULL,
Fname varchar(50),
Lname varchar(50),
Joining varchar(20),
phoneNo varchar(100),
BloodGrp varchar(10),
Nationality varchar(50));

BULK INSERT [Admin_info]
from 'C:\Users\NITB\Desktop\Admin.csv'
with (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FIRSTROW = 2
);
select * from Admin_info

create table Faculty(
ID varchar(10) NOT NULL,
Fname varchar(50),
Lname varchar(50),
num varchar(50),
numOfCourses int,
Ranks varchar(60),
status varchar(55),
Gender varchar(10),
dob varchar(20),
cnic varchar(30),
BloodGrp varchar(10),
Nationality varchar(50),
username varchar(100),
pass varchar(255));

BULK INSERT [Faculty]
from 'C:\Users\NITB\Desktop\Faculty.csv'
with (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FIRSTROW = 2
);
select * from Faculty
drop table Faculty

create table Courses(
courseID varchar(255) NOT NULL,
course_name varchar(60),
creditHours int,
preReq varchar(90));

BULK INSERT [Courses]
from 'C:\Users\NITB\Desktop\Courses.csv'
with (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FIRSTROW = 2
);
select * from Courses
drop table courses


create table Users(
UserID varchar(90) NOT NULL,
email varchar(255),
password varchar(98),
role varchar(67));

BULK INSERT [Users]
from 'C:\Users\NITB\Desktop\User.csv'
with (
FIELDTERMINATOR = ',',
ROWTERMINATOR = '\n',
FIRSTROW = 2
);
select * from Users


create table Attendance(
stuid varchar(20) NOT NULL,
name varchar(255) NOT NULL,
percentAtt int);
select * from Attendance


create table CourseAllocation(
teacher_name varchar(255) NOT NULL,
course varchar(100));

drop table CourseAllocation
select * from CourseAllocation


create table Marks_distribution(
facName varchar(50) NOT NULL,
cour_code varchar(100),
project int,
quiz int,
assignments int, 
midterm int,
final int);

select * from Marks_distribution
drop table Marks_distribution

create table feedback(
date varchar(100),
score varchar(100));

select * from feedback
drop table feedback

CREATE TRIGGER Submit_Feedback on feedback
AFTER INSERT
AS
BEGIN 
INSERT INTO log values
('Feedback submitted',getdate());
print 'Value inserted successfully'
end
select * from log


create table Marks(
ID varchar(100),
ass int, 
project int,
quiz int,
mid int,
final int,
total int);

select * from Marks
drop table Marks


create table Transcript(
grade varchar(100),
points FLOAT);

select * from Transcript
drop table Transcript