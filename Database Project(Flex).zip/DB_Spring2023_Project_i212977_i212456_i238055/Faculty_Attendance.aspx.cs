﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Faculty_Attendance : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_interface.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_setMarks.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Faculty_feedback.aspx");
    }

    


    protected void Button4_Click(object sender, EventArgs e)
    {
        string sectionName = Request.Form["students"];

        // Retrieve the section ID from the database
       

        String connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        String query = "SELECT stuID, Fname, Lanme FROM student WHERE section = @sectionName";

        using (SqlConnection connection = new SqlConnection(connectionString))
        using (SqlCommand command = new SqlCommand(query, connection))
        {
            command.Parameters.AddWithValue("@sectionName", sectionName);
            Response.Redirect("Mark_Attendance.aspx?sectionName=" + sectionName);

            connection.Open();


        }


    }
}