﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

public partial class Faculty_marks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gvStudents.Visible = false;
           
        }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        string section = txtSection.Text.Trim();
        if (string.IsNullOrEmpty(section))
        {
            return;
        }

        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        string query = "SELECT stuID, Fname, Lanme FROM student WHERE section = ('" + section + "') ORDER BY stuID ASC";
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@section", section);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                  

                    Table table = new Table();
                    while (reader.Read())
                    {
                        string studentID = reader["stuID"].ToString();
                        string firstName = reader["Fname"].ToString();
                        string lastName = reader["Lanme"].ToString();

                        // display student information in a table
                        TableRow row = new TableRow();
                        TableCell cellStudentID = new TableCell();
                        cellStudentID.Text = studentID.ToString();
                        row.Cells.Add(cellStudentID);

                        TableCell cellName = new TableCell();
                        cellName.Text = firstName + " " + lastName;
                        row.Cells.Add(cellName);

                        // add input fields for marks
                        TableCell cellAssignments = new TableCell();
                        TextBox txtAssignments = new TextBox();
                        txtAssignments.ID = "txtAssignments_" + studentID.ToString();
                        cellAssignments.Controls.Add(txtAssignments);
                        row.Cells.Add(cellAssignments);

                        TableCell cellProject = new TableCell();
                        TextBox txtProject = new TextBox();
                        txtProject.ID = "txtProject_" + studentID.ToString();
                        cellProject.Controls.Add(txtProject);
                        row.Cells.Add(cellProject);

                        TableCell cellQuiz = new TableCell();
                        TextBox txtQuiz = new TextBox();
                        txtQuiz.ID = "txtQuiz_" + studentID.ToString();
                        cellQuiz.Controls.Add(txtQuiz);
                        row.Cells.Add(cellQuiz);

                        TableCell cellMidterm = new TableCell();
                        TextBox txtMidterm = new TextBox();
                        txtMidterm.ID = "txtMidterm_" + studentID.ToString();
                        cellMidterm.Controls.Add(txtMidterm);
                        row.Cells.Add(cellMidterm);

                        TableCell cellFinal = new TableCell();
                        TextBox txtFinal = new TextBox();
                        txtFinal.ID = "txtFinal_" + studentID.ToString();
                        cellFinal.Controls.Add(txtFinal);
                        row.Cells.Add(cellFinal);


                        TableCell cellTotal = new TableCell();
                        TextBox txtTotal = new TextBox();
                        txtTotal.ID = "txtTotal_" + studentID.ToString();
                        cellTotal.Controls.Add(txtTotal);
                        row.Cells.Add(cellTotal);
                        table.Rows.Add(row);
                    }

                    // add the table to the form
                    form1.Controls.Add(table);

                    //add a save button
                    //Button btnSave = new Button();
                    //btnSave.Text = "Save";
                    //btnSave.Click += new EventHandler(Button1_Click);
                    //form1.Controls.Add(btnSave);
                }
                catch (Exception ex)
                {
                    // handle exception
                }
            }
        }
    }





    protected void Button1_Click(object sender, EventArgs e)
    {
        string connectionString = "Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True";
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            try
            {
                connection.Open();
                Dictionary<string, Dictionary<string, string>> studentData = new Dictionary<string, Dictionary<string, string>>();
                foreach (string key in Request.Form.Keys)
                {
                    if (key.StartsWith("txt"))
                    {
                        string[] parts = key.Split('_');
                        if (parts.Length == 2)
                        {
                            string ID = parts[1];
                            string type = parts[0].Substring(3);
                            string value = Request.Form[key];

                            if (!studentData.ContainsKey(ID))
                            {
                                studentData[ID] = new Dictionary<string, string>();
                            }

                            studentData[ID][type] = value;
                        }
                    }
                }

                foreach (var student in studentData)
                {
                    string ID = student.Key;
                    string ass = student.Value.ContainsKey("Assignments") ? student.Value["Assignments"] : null;
                    string project = student.Value.ContainsKey("Project") ? student.Value["Project"] : null;
                    string quiz = student.Value.ContainsKey("Quiz") ? student.Value["Quiz"] : null;
                    string mid = student.Value.ContainsKey("Midterm") ? student.Value["Midterm"] : null;
                    string final = student.Value.ContainsKey("Final") ? student.Value["Final"] : null;
                    string total = student.Value.ContainsKey("Total") ? student.Value["Total"] : null;


                    string grade = null;
                    double points = 0.0;
                    double marks = double.Parse(total);
                    if (marks >= 90)
                    {
                        grade = "A+";
                        points = 4.0;
                    }
                    else if (marks >= 85 && marks < 90)
                    {
                        grade = "A";
                        points = 3.7;
                    }
                    else if (marks >= 80 && marks < 85)
                    {
                        grade = "A-";
                        points = 3.3;
                    }
                    else if (marks >= 75 && marks < 80)
                    {
                        grade = "B+";
                        points = 3.0;
                    }
                    else if (marks >= 70 && marks < 75)
                    {
                        grade = "B";
                        points = 2.7;
                    }
                    else if (marks >= 65 && marks < 70)
                    {
                        grade = "B-";
                        points = 2.3;
                    }
                    else if (marks >= 60 && marks < 65)
                    {
                        grade = "C+";
                        points = 2.0;
                    }
                    else if (marks >= 55 && marks < 60)
                    {
                        grade = "C";
                        points = 1.7;
                    }
                    else if (marks >= 50 && marks < 55)
                    {
                        grade = "C-";
                        points = 1.3;
                    }
                    else if (marks >= 45 && marks < 50)
                    {
                        grade = "D+";
                        points = 1.0;
                    }
                    else if (marks >= 40 && marks < 45)
                    {
                        grade = "D";
                        points = 0.7;
                    }
                    else
                    {
                        grade = "F";
                        points = 0.0;
                    }



                    string query = "INSERT INTO Marks (ID, ass, project, quiz, mid, final, total) VALUES (@ID, @ass, @project, @quiz, @mid, @final, @total)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ID", ID);
                        command.Parameters.AddWithValue("@ass", ass ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@project", project ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@quiz", quiz ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@mid", mid ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@final", final ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@total", total ?? (object)DBNull.Value);
                        command.ExecuteNonQuery();
                    }


                    string query2 = "INSERT INTO Transcript (grade, points) VALUES (@grade, @points)";
                    using (SqlCommand command = new SqlCommand(query2, connection))
                    {
                    
                        command.Parameters.AddWithValue("@grade", grade ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@points", points);
                       
                        command.ExecuteNonQuery();
                    }
                }
                }
            
            catch (Exception ex)
            {
                // handle exception
            }
        }
    }

    //protected void Button2_Click(object sender, EventArgs e)
    //{

    //        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
    //    SqlCommand cm = new SqlCommand("Select ID, ass, project, quiz, mid, final, total from Marks", conn);
    //    SqlDataAdapter s = new SqlDataAdapter(cm);
    //    DataTable dt = new DataTable();
    //    s.Fill(dt);


    //    ReportDataSource rds = new ReportDataSource("Dataset1", dt);
    //    ReportViewer1.LocalReport.ReportPath = Server.MapPath("Report.rdlc");
    //    ReportViewer1.LocalReport.DataSources.Add(rds);
    //    ReportViewer1.LocalReport.Refresh();
    //}


    private string DataTableToCsv(DataTable dataTable)
    {
        StringBuilder sb = new StringBuilder();

        IEnumerable<string> columnNames = dataTable.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
        sb.AppendLine(string.Join(",", columnNames));

        foreach (DataRow row in dataTable.Rows)
        {
            IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
            sb.AppendLine(string.Join(",", fields));
        }

        return sb.ToString();
    }


    protected void Button2_Click(object sender, EventArgs e)
    {



        // Fetch data from SQL table
        DataTable data = FetchDataFromSQLTable();

        // Generate CSV content from the data
        string csvContent = DataTableToCsv(data);

        // Set response headers for file download
        Response.Clear();
        Response.ContentType = "application/pdf";

        //Response.ContentType = "text/csv";
        Response.AddHeader("Content-Disposition", "attachment; filename=report.csv");

        // Write the CSV content to the response stream
        Response.Write(csvContent);
        Response.End();

    }

    private DataTable FetchDataFromSQLTable()
    {
        // Write code to fetch data from your SQL table and populate a DataTable object.
        DataTable dt = new DataTable();
        // Sample code to populate dt with data from a SQL table
        using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True"))
        {
            SqlCommand command = new SqlCommand("Select * from Marks", connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(dt);
        }
        return dt;
    }

}







