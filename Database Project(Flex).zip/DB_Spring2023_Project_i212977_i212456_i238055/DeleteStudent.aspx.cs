﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class DeleteStudent :  System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-Q8OH4AP\\SQLEXPRESS;Initial Catalog=DBProject;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        string stuID = TextBox1.Text;
        string Fname = TextBox2.Text;
        string Lanme = TextBox3.Text;
        string batch = TextBox4.Text;
        string degree = TextBox5.Text;
        string section = TextBox6.Text;
        string campus = TextBox7.Text;
        string status = TextBox8.Text;
        string Gender = TextBox9.Text;
        string dob = TextBox10.Text;
        string CNIC = TextBox11.Text;
        string bg = TextBox12.Text;
        string nationality = TextBox13.Text;
        string phoneNo = TextBox14.Text;
        string perAdd = TextBox15.Text;
        string currAdd = TextBox16.Text;

        string query = "DELETE FROM student WHERE stuID = '" + stuID + "' AND Fname = '" + Fname + "' AND Lanme = '" + Lanme + "' AND batch = '" + batch + "' AND degree = '" + degree + "' AND section = '" + section + "' AND campus = '" + campus + "' AND status = '" + status + "' AND Gender = '" + Gender + "' AND dob = '" + dob + "' AND CNIC = '" + CNIC + "' AND bg = '" + bg + "' AND nationality = '" + nationality + "' AND phoneNo = '" + phoneNo + "' AND perAdd = '" + perAdd + "' AND currAdd = '" + currAdd + "'";

        cm = new SqlCommand(query, conn);
        cm.ExecuteNonQuery();
        cm.Dispose();
        conn.Close();
        Response.Redirect("Admin_addStu.aspx");
    }
}